
const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//======================================================Settings Bot=========================================================================//
global.owner = '6288214173300'
global.versi = version
global.namaOwner = "Malzhost"
global.packname = 'Bot WhatsApp'
global.botname = 'Senju Kawaragi'
global.botname2 = 'Senju Kawaragi'

//=====================================//
global.linkOwner = "https://wa.me/6288214173300"
global.linkGrup = "https://chat.whatsapp.com/GM9Z8O3LKI5DRyBvmmukrc"

//=====================================//
global.delayJpm = 3500
global.delayPushkontak = 6000

//=====================================//
global.linkSaluran = "https://whatsapp.com/channel/0029VazQ8mOIyPtafL4szS25"
global.idSaluran = "120363393124074988@newsletter"
global.namaSaluran = "MalzHost || Dev Senju"

//=====================================//
global.dana = "089516142268" //Isi aja payment lu
global.ovo = "085773367326"
global.gopay = "085773367326"

//=====================================//
global.image = {
menu: "https://img1.pixhost.to/images/6574/612316177_malzhost.jpg", //Ubah aja jdi image lu
reply: "https://img1.pixhost.to/images/6574/612316177_malzhost.jpg", 
logo: "https://img1.pixhost.to/images/6574/612316177_malzhost.jpg", 
qris: "https://files.catbox.moe/2x31tb.jpg"//Ubah aja jdi foto qris lu
}

//=====================================//
global.mess = {
	owner: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Owner Bot ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	admin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Admin Group ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	botAdmin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Bot Harus Jadi Admin Terlebih dahulu ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	group: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya berlaku di Group ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	private: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya dapat di lakukan di private cht ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	prem: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya Untuk User Premium ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
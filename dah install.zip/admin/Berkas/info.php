<div class="row g-gs">
                                        <div class="col-md-6 col-xxl-3" data-content="views">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner mb-n2">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Top Tools View by Users</h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="nk-tb-list is-compact">
                                                    <div class="nk-tb-item nk-tb-head">
                                                        <div class="nk-tb-col"><span>Page</span></div>
                                                        <div class="nk-tb-col text-right"><span>Views</span></div>
                                                    </div><!-- .nk-tb-head -->
                                                    <?php $ResultView = mysqli_query($config,"SELECT * FROM PageView ORDER BY view DESC LIMIT 10");
                                                    while ($rowResultView = mysqli_fetch_array($ResultView)) {
                                                    ?>
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <span class="tb-sub"><span>/?tools=<?= $rowResultView['link'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $rowResultView['view']?></span></span>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <? } ?>
                                                </div><!-- .nk-tb-list -->
                                            </div><!-- .card -->
                                        </div>
                                        <div class="col-md-6 col-xxl-3">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner h-100 stretch flex-column">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Sessions by Device</h6>
                                                        </div>
                                                    </div>
                                                    <div class="device-status my-auto">
                                                        <div class="device-status-ck">
                                                            <canvas class="analytics-doughnut" id="deviceStatusData"></canvas>
                                                        </div>
                                                        <div class="device-status-group">
                                                            <div class="device-status-data">
                                                                <em data-color="#798bff" class="icon ni ni-monitor"></em>
                                                                <div class="title">Desktop</div>
                                                                <div class="amount"><?= $PersentaseDesk ?>%</div>
                                                                <div class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em><?= $DesktopDevice['view'] ?></div>
                                                            </div>
                                                            <div class="device-status-data">
                                                                <em data-color="#baaeff" class="icon ni ni-mobile"></em>
                                                                <div class="title">Mobile</div>
                                                                <div class="amount"><?= $PersentaseMob ?>%</div>
                                                                <div class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em><?= $MobileDevice['view'] ?></div>
                                                            </div>
                                                        </div><!-- .device-status-group -->
                                                    </div><!-- .device-status -->
                                                </div>
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        
                                        <div class="col-xxl-6">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner mb-n2">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Browser Used By Visitor</h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="nk-tb-list is-loose">
                                                    <div class="nk-tb-item nk-tb-head">
                                                        <div class="nk-tb-col"><span>Browser</span></div>
                                                        <div class="nk-tb-col text-right"><span>Visitor</span></div>
                                                        <div class="nk-tb-col"><span>% Visitor</span></div>
                                                    </div><!-- .nk-tb-head -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-teal icon ni ni-b-chrome"></em>
                                                                <span class="tb-lead">Google Chrome</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $chrome['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenchrome ?>"></div>
                                                                <div class="progress-amount"><?= $Persenchrome ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-blue icon ni ni-b-firefox"></em>
                                                                <span class="tb-lead">Mozilla Firefox</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $mozilla['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenmozilla ?>"></div>
                                                                <div class="progress-amount"><?= $Persenmozilla ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-info icon ni ni-b-safari"></em>
                                                                <span class="tb-lead">Safari Browser</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $safari['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persensafari ?>"></div>
                                                                <div class="progress-amount"><?= $Persensafari ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-danger icon ni ni-b-opera"></em>
                                                                <span class="tb-lead">Opera</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $opera['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenopera ?>"></div>
                                                                <div class="progress-amount"><?= $Persenopera ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-purple icon ni ni-b-si"></em>
                                                                <span class="tb-lead">Other Browser</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $otherb['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenotherb ?>"></div>
                                                                <div class="progress-amount"><?= $Persenotherb ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                </div><!-- .nk-tb-list -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        <div class="col-md-6 col-xxl-3">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner h-100 stretch flex-column">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Threat Log</h6>
                                                        </div>
                                                    </div><br>
                                                    <? $Threat = file_get_contents('../home/threat_log'); $Threat2 = file_get_contents('../home2/threat_log');  ?>
                                                    <textarea rows="10" cols="50" class="form-control text-danger" readonly><?php echo $Threat; echo $Threat2; ?></textarea>
                                                </div>
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        <div class="col-md-6 col-xxl-3">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner h-100 stretch flex-column">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">IP Blocked</h6>
                                                        </div>
                                                    </div><br>
                                                    <? $hwkr = file_get_contents('../home/hwkr.txt'); $hwkr2 = file_get_contents('../home2/hwkr.txt');  ?>
                                                    <textarea rows="10" cols="50" class="form-control text-danger" readonly><?php echo $hwkr; echo $hwkr2; ?></textarea>
                                                </div>
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                    </div>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                
                                <div class="nk-block">
                                    <div class="row g-gs">
                                        
                                        
                                        

<?php
$JudulTools = $_GET['tools'];
                $resultJudul = mysqli_query($config, "SELECT * FROM tools2 WHERE link='$JudulTools'");
                $insertView = mysqli_query($config, "UPDATE PageView SET view = view+1 WHERE link='$JudulTools'");
                while ($rowReportJudul = mysqli_fetch_array($resultJudul)) {
include'sec.php';
error_reporting(0);
?>                                
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header bg-<? echo $general_sidebar_color['general_value'] ?>"><p>
                                                <?php echo $rowReportJudul['judul']; ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
                                        <?php include'../Berkas/include.php' ?>
</div><!-- .row -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div><? } ?>
                                    </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->    
                                        
                                        
                                    </div><!-- .row -->
                                </div><!-- .nk-block -->
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex,nofollow">
    <!-- Page Title  -->
    <title><?php echo $general_title['general_value']." | Admin";?></title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="assets/css/dashlite.css?ver=2.4.0">
    <link id="skin-default" rel="stylesheet" href="assets/css/theme.css?ver=2.4.0">
 <link rel="stylesheet" type="text/css" href="assets/css/libs/fontawesome-icons.css"> 
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="assets/css/libs/themify-icons.css">
 <link rel="stylesheet" type="text/css" href="assets/css/libs/bootstrap-icons.css">
  <script type="text/javascript" src="../assets/jquery/jquery.min.js"></script>
  <script type="text/javascript" src="../assets/jquery/jquery.slim.min.js"></script>
</head>
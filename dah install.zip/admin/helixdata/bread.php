<div class="nk-content ">
    <div class="card card-preview">
        <div class="card-inner">
            <nav>
                <ul class="breadcrumb breadcrumb-arrow">
                    <?php if(isset($_GET["index"])) {echo'<li class="breadcrumb-item text-danger"><a href="./?index" class="text-indigo">Dashboard '.$general_title['general_value'].'</a></li>';}
                        elseif(isset($_GET["Pages-Edit"])) { echo'<li class="breadcrumb-item"><a href="javascript:void(0);">Edit</a></li>';}
                        elseif(isset($_GET["Blog-Edit"])) { echo'<li class="breadcrumb-item"><a href="javascript:void(0);">Edit</a></li>';}
                        else { echo'<li class="breadcrumb-item"><a href="javascript:void(0);">Setting</a></li>';}?>
<?php
                        if(isset($_GET['General'])) {
    ?> 
    <li class="breadcrumb-item">General</li>
    <? } ?>
<?php
                        if(isset($_GET['Themes'])) {
    ?> 
    <li class="breadcrumb-item">Themes</li>
    <? } ?>
<?php
                        if(isset($_GET['Ads'])) {
    ?> 
    <li class="breadcrumb-item">Advertising</li>
    <? } ?>
    <?php
                        if(isset($_GET['Profile'])) {
    ?> 
    <li class="breadcrumb-item">Profile</li>
    <? } ?>

                        <?php
                        if(isset($_GET['Pages'])) {
    ?> 
    <li class="breadcrumb-item">Pages</li>
    <? } ?>
    <?php
                        if(isset($_GET['Blog'])) {
    ?> 
    <li class="breadcrumb-item">Blog</li>
    <? } ?>
    <?php
                        if(isset($_GET['Pages-Edit'])) { $id = $_GET['Pages-Edit'];
    $content = mysqli_fetch_array(mysqli_query($config,"SELECT * FROM contents WHERE ID='$id'"));
    ?> 
    <li class="breadcrumb-item">Pages</li>
    <li class="breadcrumb-item active"  aria-current="page"><?=$content['content_title']?></li>
    <? } ?>
    <?php
                        if(isset($_GET['Blog-Edit'])) { $id = $_GET['Blog-Edit'];
    $content = mysqli_fetch_array(mysqli_query($config,"SELECT * FROM Blog WHERE ID='$id'"));
    ?> 
    <li class="breadcrumb-item">Post</li>
    <li class="breadcrumb-item active"  aria-current="page"><?=$content['Blog_title']?></li>
    <? } ?>
    
                </ul>
            </nav>
        </div>
    </div>
</div>


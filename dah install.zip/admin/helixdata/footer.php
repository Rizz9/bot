
            </div>
            
            <!-- Penting 2 Div  -->
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    
    <!-- app-root @e -->
    <!-- JavaScript -->
    <footer>
        <div class="footer-wrapper text-center">
<div class="footer-section f-section-1">
    <p class="">Copyright © <? echo date(Y) ?> <a href="https://www.helixsid.today" target="_blank">Helix </a> & 4DSec - Site By Helix</p>
</div>
                </div>
    </footer>
    <script src="./assets/js/bundle.js?ver=2.4.0"></script>
    <script src="./assets/js/scripts.js?ver=2.4.0"></script>
    <? include '../home/Berkas/analytic.php'?>
    <script src="./assets/js/libs/jqvmap.js?ver=2.4.0"></script>
    <link rel="stylesheet" href="./assets/css/editors/summernote.css?ver=2.4.0">
    <script src="./assets/js/libs/editors/summernote.js?ver=2.4.0"></script>
    <script src="./assets/js/editors.js?ver=2.4.0"></script>

</body>

</html>
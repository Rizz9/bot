                <!-- Header  -->
                <!-- main header @s -->
                <div class="nk-header nk-header-fixed bg-<? echo $general_header_color['general_value'] ?>">
                    <div class="container-fluid">
                        <div class="nk-header-wrap">
                            <div class="nk-menu-trigger d-xl-none ml-n1">
                                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                            </div>
                            <div class="nk-header-app-name">
                                <div class="nk-header-app-logo">
                                    <img src="<? echo $general_logo['general_value']?>" alt="" class="rounded-circle">
                                </div>
                                <div class="nk-header-app-info">
                                    <span class="sub-text"><? echo "Version ".$AppVersion['general_value'].""?></span>
                                    <span class="lead-text"><? echo 'Admin Dashboard'?></span>
                                </div>
                            </div>
                            <div class="nk-header-menu is-light">
                                <div class="nk-header-menu-inner">
                                    <!-- Menu -->
                                    <ul class="nk-menu nk-menu-main">
                                        <li class="nk-menu-item">
                                            <a href="../home/?index" class="nk-menu-link">
                                                <span class="nk-menu-text">Home</span>
                                            </a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="../home2/?index" class="nk-menu-link">
                                                <span class="nk-menu-text">Home 2</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <!-- Menu -->
                                </div>
                            </div>
                            
                            <div class="nk-header-tools">
                                <ul class="nk-quick-nav">
                                    <li class="dropdown list-apps-dropdown d-lg-none">
                                        <a href="#" class="dropdown-toggle nk-quick-nav-icon" data-toggle="dropdown">
                                            <div class="icon-status icon-status-na"><em class="icon ni ni-menu-circled"></em></div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                                            <div class="dropdown-body">
                                                <ul class="list-apps">
                                                    <li>
                                                        <a href="../home/?index">
                                                            <span class="list-apps-media"><img src="<? echo $general_logo['general_value']?>" alt="" class="rounded-circle"></em></span>
                                                            <span class="list-apps-title">Home Tools</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://wa.me/6289524925615">
                                                            <span class="list-apps-media"><em class="icon ni ni-chat-circle bg-info-dim"></em></span>
                                                            <span class="list-apps-title">Contact Support</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://files.helixsid.today" target="_blank">
                                                            <span class="list-apps-media"><em class="icon ni ni-folder bg-purple-dim"></em></span>
                                                            <span class="list-apps-title">Open Source Repository</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div><!-- .nk-dropdown-body -->
                                        </div>
                                    </li>
                                    <li class="dropdown user-dropdown">
                                        <a href="#" class="dropdown-toggle mr-n1" data-toggle="dropdown">
                                            <div class="user-toggle">
                                                <div class="user-avatar sm">
                                                    <img src="<? echo $general_owner_logo['general_value']?>" alt="">
                                                </div>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-md dropdown-menu-right">
                                            <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                                <div class="user-card">
                                                    <div class="user-avatar">
                                                        <img src="<? echo $general_owner_logo['general_value']?>" alt="">
                                                    </div>
                                                    <div class="user-info">
                                                        <span class="lead-text"><? echo $general_owner['general_value']?></span>
                                                        <span class="sub-text"><? echo $general_owner_email['email']?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="dropdown-inner">
                                                <ul class="link-list">
                                                    <li><a href="./admin.php?Profile"><em class="icon ni ni-user-alt"></em><span>View Profile</span></a></li>
                                                    <li><a class="dark-switch" href="#"><em class="icon ni ni-moon"></em><span>Dark Mode</span></a></li>
                                                </ul>
                                            </div>
                                            <div class="dropdown-inner">
                                                <ul class="link-list">
                                                    <li><a href="./logout.php"><em class="icon ni ni-signout"></em><span>Sign out</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Header  -->
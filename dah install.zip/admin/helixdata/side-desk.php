<!-- SideDesk  -->        
        <div class="nk-apps-sidebar bg-<? echo $general_sidebar_color['general_value'] ?>">
            <div class="nk-apps-brand">
                <a href="index" class="logo-link">
                    <img class="logo-light logo-img" src="<? echo $general_logo['general_value']?>" srcset="<? echo $general_logo['general_value']?> 2x" alt="logo" class="rounded-circle">
                    <img class="logo-dark logo-img" src="<? echo $general_logo['general_value']?>" srcset="<? echo $general_logo['general_value']?>" alt="logo-dark" class="rounded-circle">
                </a>
            </div>
            <div class="nk-sidebar-element">
                <div class="nk-sidebar-body">
                    <div class="nk-sidebar-content" data-simplebar>
                        <div class="nk-sidebar-menu">
                            <!-- Menu -->
                            <ul class="nk-menu apps-menu">
                                <li class="nk-menu-item">
                                    <a href="./admin.php?index" class="nk-menu-link" title="Home">
                                        <span class="nk-menu-icon"><em class="icon ni ni-dashboard"></em></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="nk-sidebar-footer bg-<? echo $general_sidebar_color['general_value'] ?>">
                            <ul class="nk-menu nk-menu-md">
                                <li class="nk-menu-item">
                                    <a href="#" class="nk-menu-link" title="Settings">
                                        <span class="nk-menu-icon"><em class="icon ni ni-setting"></em></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="nk-sidebar-profile nk-sidebar-profile-fixed dropdown bg-<? echo $general_sidebar_color['general_value'] ?>">
                        <a href="#" data-toggle="dropdown" data-offset="50,-60">
                            <div class="user-avatar">
                                <img src="<? echo $general_owner_logo['general_value']?>" alt="">
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-md ml-4">
                            <div class="dropdown-inner user-card-wrap d-none d-md-block">
                                <div class="user-card">
                                    <div class="user-avatar">
                                        <img src="<? echo $general_owner_logo['general_value']?>" alt="">
                                    </div>
                                    <div class="user-info">
                                        <span class="lead-text"><? echo $general_owner['general_value']?></span>
                                        <span class="sub-text text-soft"><? echo $general_owner_email['email']?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <li><a href="./admin.php?Profile"><em class="icon ni ni-user-alt"></em><span>View Profile</span></a></li>
                                </ul>
                            </div>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <li><a href="./logout.php"><em class="icon ni ni-signout"></em><span>Sign out</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!-- SideDesk  -->
<body class="nk-body npc-default has-apps-sidebar has-sidebar bg-<? echo $general_body_color['general_value'] ?>">
    <div class="nk-app-root">
        <? include'helixdata/side-desk.php'; ?>
        <!-- main @s -->
        <div class="nk-main ">
            <!-- wrap @s -->
            <div class="nk-wrap ">
                <? include'helixdata/mainheader.php'; include'helixdata/side.php';?>
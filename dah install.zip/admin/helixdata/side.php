                <!-- SideM  -->
                <div class="nk-sidebar bg-<? echo $general_sidebar_color['general_value'] ?>" data-content="sidebarMenu">
                    <div class="nk-sidebar-inner" data-simplebar>
                        <ul class="nk-menu nk-menu-md">
                            <li class="nk-menu-heading">
                                <h6 class="overline-title text-primary-alt">Dashboards</h6>
                            </li><!-- .nk-menu-heading -->
                            <li class="nk-menu-item">
                                <a href="./admin.php?index" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-dashboard text-indigo"></em></span>
                                    <span class="nk-menu-text"> Home</span>
                                </a>
                            </li><!-- .nk-menu-item -->
                            <li class="nk-menu-heading">
                                <h6 class="overline-title text-primary-alt">Admin</h6>
                            </li><!-- .nk-menu-heading -->
                            <li class="nk-menu-item">
                                <a href="./admin.php?General" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-setting text-indigo"></em></span>
                                    <span class="nk-menu-text"> General Setting</span>
                                </a>
                            </li><!-- .nk-menu-item -->
                            <li class="nk-menu-item">
                                <a href="./admin.php?Themes" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-img text-teal"></em></span>
                                    <span class="nk-menu-text"> Themes Setting</span>
                                </a>
                            </li><!-- .nk-menu-item -->
                            <li class="nk-menu-item">
                                <a href="./admin.php?Ads" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-coin-alt text-blue"></em></span>
                                    <span class="nk-menu-text"> ADS Setting</span>
                                </a>
                            </li><!-- .nk-menu-item -->
                            <li class="nk-menu-item">
                                <a href="./admin.php?Profile" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-account-setting text-info"></em></span>
                                    <span class="nk-menu-text"> Owner Setting</span>
                                </a>
                            </li><!-- .nk-menu-item -->
                            <li class="nk-menu-item">
                                <a href="./admin.php?Pages" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-edit-alt text-azure"></em></span>
                                    <span class="nk-menu-text"> Pages Setting</span>
                                </a>
                            </li>
                            <li class="nk-menu-item">
                                <a href="./admin.php?Blog" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-edit text-danger"></em></span>
                                    <span class="nk-menu-text"> Blog Setting</span>
                                </a>
                            </li>
                            <li class="nk-menu-item">
                                <a href="./admin.php?About" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-info text-info"></em></span>
                                    <span class="nk-menu-text">About</span>
                                </a>
                            </li><!-- .nk-menu-item -->
                            
                            <li class="nk-menu-heading">
                                <h6 class="overline-title text-primary-alt">Main</h6>
                            </li><!-- .nk-menu-heading -->
                            
                            <li class="nk-menu-item">
                                <a href="https://wa.me/6289524925615" class="nk-menu-link">
                                    <span class="nk-menu-icon"><em class="icon ni ni-whatsapp text-info"></em></span>
                                    <span class="nk-menu-text">Contact Helix</span>
                                </a>
                            </li><!-- .nk-menu-item -->
                        </ul><!-- .nk-menu -->
                    </div>
                </div>
                <!-- SideM  -->
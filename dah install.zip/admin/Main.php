<?php
include'./session.php';?>

                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <?php if(isset($_GET['index'])){ include'./Berkas/info.php';}?>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
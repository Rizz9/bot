<?php
	session_start();
	include('../config.php');
	
	if (!isset($_SESSION['id']) ||(trim ($_SESSION['id']) == '')) {
	header('location: ./index.php');
    exit();
	}
	
	$sq=mysqli_query($config,"select * from `admin` where adminid='".$_SESSION['id']."'");
	$srow=mysqli_fetch_array($sq);
		
	if ($srow['access']!=1){
		header('location: ./admin.php?index');
		exit();
	}
?>
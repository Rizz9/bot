<?php include('./session.php'); ?>
<?php
	include('../general.php');
	include'helixdata/head.php';
include'helixdata/sidebar.php';
include'helixdata/bread.php'; ?>

      <!-- Index Primary Content -->
<?php if(isset($_GET["index"])) { 
    include'./Main.php';
} elseif(isset($_GET["Ads"])) {
    include'./Action/ads.php';
} elseif(isset($_GET["Profile"])) {
    include'./Action/profile.php';
} elseif(isset($_GET["Themes"])) {
    include'./Action/themes.php';
} elseif(isset($_GET["General"])) {
    include'./Action/general.php';
} elseif(isset($_GET["Pages"])) {
    include'./Action/pages.php';
} elseif(isset($_GET["Pages-Create"])) {
    include'./Action/pages-create.php';
} elseif(isset($_GET["Pages-Edit"])) {
    include'./Action/pages-edit.php';
} elseif(isset($_GET["Blog"])) {
    include'./Action/blog.php';
} elseif(isset($_GET["Blog-Create"])) {
    include'./Action/blog-create.php';
} elseif(isset($_GET["Blog-Edit"])) {
    include'./Action/blog-edit.php';
} elseif(isset($_GET["About"])) {
    include'./Action/about.php';
}
include'helixdata/footer.php' ?>
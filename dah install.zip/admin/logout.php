<?php
	session_start();
	include('../config.php');
	
	$_SESSION['id'] = '';
	unset($_SESSION['id']);
	session_unset();
	session_destroy();
	header('location: ./index.php');
?>
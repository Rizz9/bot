<?php if (isset($_SESSION['id']) === true) { ?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-<? echo $general_body_color['general_value']; ?>">
                        <h5 class="title">Create Pages</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        date_default_timezone_set('Asia/Makassar');
                            if(isset($_POST['submit'])){
                            $Title = $_POST['title'];
                            $desc = $_POST['desc'];
                            $slug = strtolower(str_replace(" ","-","$Title"));
                            $text = $_POST['text'];
                            $date = $_POST['date'];
                            $Insert1 = mysqli_query($config,"INSERT INTO `contents` (`ID`, `content_type`, `content_title`, `content_description`, `content_slug`, `content_text`, `content_opt`) VALUES (NULL, '1', '$Title', '$desc', '$slug', '$text', '$date')");
                            echo '<p class="alert alert-success">Pages saved. Refresh......</p>';
                            echo '<script>setTimeout(function(){ window.location.href = "./admin.php?Pages"; }, 1000);</script>';
                            }
                        ?>
                        <form method="post">
                        <div class="row gy-4">
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="title" placeholder="Blablabla" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Pages Title</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="desc" placeholder="Blablabla" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Description</label>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="date" name="date" class="form-control" value="<?= date('M d, Y')?>" autofocus="" required autocomplete="off">
                            <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Pages Content</h4>
                                                <div class="nk-block-des">
                                                    <p class="text-danger">Note : Upload Image Akan Membuat Website Sedikit Melambat, Di Sarankan Untuk Insert Link Image Saja</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-bordered">
                                            <div class="card-inner">
                                                <textarea class="summernote-basic" name="text"></textarea>
                                            </div>
                                        </div>
                            </div>
                        </div>
                        <br>
                            <div class="form-group text-center">
                                <button type="submit" name="submit" class="btn btn-info btn-fill btn-wd">Save</button>
                            </div>
                            </form>
                            
                            
                    </div>
                </div>
            </div>
        </div>
</div>
                        </div>
                    </div>
                </div>
                <link rel="stylesheet" href="./assets/css/editors/summernote.css?ver=2.4.0">
    <script src="./assets/js/libs/editors/summernote.js?ver=2.4.0"></script>
    <script src="./assets/js/editors.js?ver=2.4.0"></script>
                <!-- content @e -->
<?php } else {
    http_response_code(404);
} ?>
<?php if (isset($_SESSION['id']) === true) { ?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-<? echo $general_body_color['general_value']; ?>">
                        <h5 class="title">Themes Setting</h5>
                    </div>
                    <div class="card-body">
                        <?php
                            if(isset($_POST['submit'])){
                            $head = $_POST['head'];
                            $sidebar = $_POST['sidebar'];
                            $body = $_POST['body'];
                            $Insert1 = mysqli_query($config,"UPDATE General SET general_value = '$head' WHERE general_id = '20'");
                            $Insert2 = mysqli_query($config,"UPDATE General SET general_value = '$sidebar' WHERE general_id = '21'");
                            $Insert3 = mysqli_query($config,"UPDATE General SET general_value = '$body' WHERE general_id = '19'");
                            echo '<p class="alert alert-success">Settings saved. Refresh......</p>';
                            echo '<script>setTimeout(function(){ window.location.replace(window.location.href); }, 1000);</script>';
                            }
                        ?>
                        <form method="post">
                            
                                                        <div class="form-group">
                                                            <label class="form-label">Header Color</label>
                                                            <div class="form-control-wrap">
                                                                <select class="form-select form-control form-control-lg" name="head" data-search="on">
                                                                    <option value="white">White</option>
                                                                    <option value="primary">Purple</option>
                                                                    <option value="secondary">Dark Gray</option>
                                                                    <option value="dark">Dark</option>
                                                                    <option value="gray">Gray</option>
                                                                    <option value="success">Light Green</option>
                                                                    <option value="danger">Red</option>
                                                                    <option value="warning">Gold</option>
                                                                    <option value="info">Aqua</option>
                                                                    <option value="light">Light</option>
                                                                    <option value="lighter">Lighter</option>
                                                                    <option value="white-dim">White (Pale Color)</option>
                                                                    <option value="primary-dim">Purple (Pale Color)</option>
                                                                    <option value="secondary-dim">Dark Gray (Pale Color)</option>
                                                                    <option value="dark-dim">Dark (Pale Color)</option>
                                                                    <option value="gray-dim">Gray (Pale Color)</option>
                                                                    <option value="success-dim">Light Green (Pale Color)</option>
                                                                    <option value="danger-dim">Red (Pale Color)</option>
                                                                    <option value="warning-dim">Gold (Pale Color)</option>
                                                                    <option value="info-dim">Aqua (Pale Color)</option>
                                                                    <option value="blue">Blue</option>
                                                                    <option value="azure">Azure</option>
                                                                    <option value="indigo">Indigo</option>
                                                                    <option value="purple">Light Purple</option>
                                                                    <option value="pink">Pink</option>
                                                                    <option value="orange">Orange</option>
                                                                    <option value="teal">Teal</option>
                                                                    <option value="blue-dim">Blue (Pale Color)</option>
                                                                    <option value="azure-dim">Azure (Pale Color)</option>
                                                                    <option value="indigo-dim">Indigo (Pale Color)</option>
                                                                    <option value="purple-dim">Light Purple (Pale Color)</option>
                                                                    <option value="pink-dim">Pink (Pale Color)</option>
                                                                    <option value="orange-dim">Orange (Pale Color)</option>
                                                                    <option value="teal-dim">Teal (Pale Color)</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="form-label">Sidebar Color</label>
                                                            <div class="form-control-wrap">
                                                                <select class="form-select form-control form-control-lg" name="sidebar" data-search="on">
                                                                    <option value="white">White</option>
                                                                    <option value="primary">Purple</option>
                                                                    <option value="secondary">Dark Gray</option>
                                                                    <option value="dark">Dark</option>
                                                                    <option value="gray">Gray</option>
                                                                    <option value="success">Light Green</option>
                                                                    <option value="danger">Red</option>
                                                                    <option value="warning">Gold</option>
                                                                    <option value="info">Aqua</option>
                                                                    <option value="light">Light</option>
                                                                    <option value="lighter">Lighter</option>
                                                                    <option value="white-dim">White (Pale Color)</option>
                                                                    <option value="primary-dim">Purple (Pale Color)</option>
                                                                    <option value="secondary-dim">Dark Gray (Pale Color)</option>
                                                                    <option value="dark-dim">Dark (Pale Color)</option>
                                                                    <option value="gray-dim">Gray (Pale Color)</option>
                                                                    <option value="success-dim">Light Green (Pale Color)</option>
                                                                    <option value="danger-dim">Red (Pale Color)</option>
                                                                    <option value="warning-dim">Gold (Pale Color)</option>
                                                                    <option value="info-dim">Aqua (Pale Color)</option>
                                                                    <option value="blue">Blue</option>
                                                                    <option value="azure">Azure</option>
                                                                    <option value="indigo">Indigo</option>
                                                                    <option value="purple">Light Purple</option>
                                                                    <option value="pink">Pink</option>
                                                                    <option value="orange">Orange</option>
                                                                    <option value="teal">Teal</option>
                                                                    <option value="blue-dim">Blue (Pale Color)</option>
                                                                    <option value="azure-dim">Azure (Pale Color)</option>
                                                                    <option value="indigo-dim">Indigo (Pale Color)</option>
                                                                    <option value="purple-dim">Light Purple (Pale Color)</option>
                                                                    <option value="pink-dim">Pink (Pale Color)</option>
                                                                    <option value="orange-dim">Orange (Pale Color)</option>
                                                                    <option value="teal-dim">Teal (Pale Color)</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="form-label">Body Color</label>
                                                            <div class="form-control-wrap">
                                                                <select class="form-select form-control form-control-lg" name="body" data-search="on">
                                                                    <option value="white">White</option>
                                                                    <option value="primary">Purple</option>
                                                                    <option value="secondary">Dark Gray</option>
                                                                    <option value="dark">Dark</option>
                                                                    <option value="gray">Gray</option>
                                                                    <option value="success">Light Green</option>
                                                                    <option value="danger">Red</option>
                                                                    <option value="warning">Gold</option>
                                                                    <option value="info">Aqua</option>
                                                                    <option value="light">Light</option>
                                                                    <option value="lighter">Lighter</option>
                                                                    <option value="white-dim">White (Pale Color)</option>
                                                                    <option value="primary-dim">Purple (Pale Color)</option>
                                                                    <option value="secondary-dim">Dark Gray (Pale Color)</option>
                                                                    <option value="dark-dim">Dark (Pale Color)</option>
                                                                    <option value="gray-dim">Gray (Pale Color)</option>
                                                                    <option value="success-dim">Light Green (Pale Color)</option>
                                                                    <option value="danger-dim">Red (Pale Color)</option>
                                                                    <option value="warning-dim">Gold (Pale Color)</option>
                                                                    <option value="info-dim">Aqua (Pale Color)</option>
                                                                    <option value="blue">Blue</option>
                                                                    <option value="azure">Azure</option>
                                                                    <option value="indigo">Indigo</option>
                                                                    <option value="purple">Light Purple</option>
                                                                    <option value="pink">Pink</option>
                                                                    <option value="orange">Orange</option>
                                                                    <option value="teal">Teal</option>
                                                                    <option value="blue-dim">Blue (Pale Color)</option>
                                                                    <option value="azure-dim">Azure (Pale Color)</option>
                                                                    <option value="indigo-dim">Indigo (Pale Color)</option>
                                                                    <option value="purple-dim">Light Purple (Pale Color)</option>
                                                                    <option value="pink-dim">Pink (Pale Color)</option>
                                                                    <option value="orange-dim">Orange (Pale Color)</option>
                                                                    <option value="teal-dim">Teal (Pale Color)</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group text-center">
                                <button type="submit" name="submit" class="btn btn-info btn-fill btn-wd">Save</button>
                            </div>
                            
                        </form>
                        <h5 class="overline-title">Theme Color</h5>
                                                <div class="d-flex flex-wrap bg-white text-center fs-12px">
                                                    <div class="w-80px flex-fill p-2 bg-primary text-white">Purple</div>
                                                    <div class="w-80px flex-fill p-2 bg-secondary text-white">Dark Gray</div>
                                                    <div class="w-80px flex-fill p-2 bg-dark text-white">Dark</div>
                                                    <div class="w-80px flex-fill p-2 bg-gray text-white">Gray</div>
                                                    <div class="w-80px flex-fill p-2 bg-success text-white">Green</div>
                                                    <div class="w-80px flex-fill p-2 bg-danger text-white">Red</div>
                                                    <div class="w-80px flex-fill p-2 bg-warning text-dark">Gold</div>
                                                    <div class="w-80px flex-fill p-2 bg-info text-white">Aqua</div>
                                                    <div class="w-80px flex-fill p-2 bg-blue text-white">Blue</div>
                                                    <div class="w-80px flex-fill p-2 bg-azure text-white">Azure</div>
                                                    <div class="w-80px flex-fill p-2 bg-indigo text-white">Indigo</div>
                                                    <div class="w-80px flex-fill p-2 bg-purple text-white">Light Purple</div>
                                                    <div class="w-80px flex-fill p-2 bg-pink text-white">Pink</div>
                                                    <div class="w-80px flex-fill p-2 bg-orange text-white">Orange</div>
                                                    <div class="w-80px flex-fill p-2 bg-teal text-white">Teal</div>
                                                </div>
                                                <h5 class="overline-title mt-4">Theme Pale Color</h5>
                                                <div class="d-flex flex-wrap bg-white text-center fs-12px">
                                                    <div class="w-80px flex-fill p-2 bg-primary-dim text-primary">Purple</div>
                                                    <div class="w-80px flex-fill p-2 bg-secondary-dim text-secondary">Dark Gray</div>
                                                    <div class="w-80px flex-fill p-2 bg-dark-dim text-dark">Dark</div>
                                                    <div class="w-80px flex-fill p-2 bg-gray-dim text-gray">Gray</div>
                                                    <div class="w-80px flex-fill p-2 bg-success-dim text-success">Green</div>
                                                    <div class="w-80px flex-fill p-2 bg-danger-dim text-danger">Red</div>
                                                    <div class="w-80px flex-fill p-2 bg-warning-dim text-warning">Gold</div>
                                                    <div class="w-80px flex-fill p-2 bg-info-dim text-info">Aqua</div>
                                                    <div class="w-80px flex-fill p-2 bg-blue-dim text-blue">Blue</div>
                                                    <div class="w-80px flex-fill p-2 bg-azure-dim text-azure">Azure</div>
                                                    <div class="w-80px flex-fill p-2 bg-indigo-dim text-indigo">Indigo</div>
                                                    <div class="w-80px flex-fill p-2 bg-purple-dim text-purple">Light Purple</div>
                                                    <div class="w-80px flex-fill p-2 bg-pink-dim text-pink">Pink</div>
                                                    <div class="w-80px flex-fill p-2 bg-orange-dim text-orange">Orange</div>
                                                    <div class="w-80px flex-fill p-2 bg-teal-dim text-teal">Teal</div>
                                                </div>
                                                <h5 class="overline-title mt-4">Theme Lighten Color</h5>
                                                <div class="d-flex bg-white text-center fs-12px">
                                                    <div class="w-120px p-2 bg-light text-dark">light</div>
                                                    <div class="w-120px p-2 bg-lighter text-dark">lighter</div>
                                                    <div class="w-120px p-2 bg-white border border-light">white</div>
                                                </div>
                        
                    </div>
                </div>
            </div>
        </div>
</div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
<?php } else {
    http_response_code(404);
} ?>
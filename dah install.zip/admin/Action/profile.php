<?php if (isset($_SESSION['id']) === true) { ?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-<? echo $general_body_color['general_value']; ?>">
                        <h5 class="title">Owner Setting</h5>
                    </div>
                    <div class="card-body">
                        <?php
                            if(isset($_POST['submit'])){
                            $Admin = $_POST['admin'];
                            $Pass = md5($_POST['adminpass']);
                            $Email = $_POST['email'];
                            $Insert1 = mysqli_query($config,"UPDATE admin SET adminname = '$Admin'");
                            $Insert2 = mysqli_query($config,"UPDATE admin SET password = '$Pass'");
                            $Insert3 = mysqli_query($config,"UPDATE admin SET email = '$Email'");
                            echo '<p class="alert alert-success">Settings saved. Refresh......</p>';
                            echo '<script>setTimeout(function(){ window.location.replace(window.location.href); }, 1000);</script>';
                            }
                        ?>
                        <form method="post">
                        <div class="row gy-4">
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="admin" placeholder="Helixs" value="<? echo $general_admin['adminname']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Admin Name</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="password" name="adminpass" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >New Password</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="email" name="email" placeholder="admin@helixsid.today" value="<? echo $general_admin['email']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Admin Email</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                            <div class="form-group text-center">
                                <button type="submit" name="submit" class="btn btn-info btn-fill btn-wd">Save</button>
                            </div>
                            </form>
                        
                    </div>
                </div>
            </div>
        </div>
</div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
<?php } else {
    http_response_code(404);
} ?>
<?php if (isset($_SESSION['id']) === true) { ?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-<? echo $general_body_color['general_value']; ?>">
                        <h5 class="title">General Setting</h5>
                    </div>
                    <div class="card-body">
                        <?php
                            if(isset($_POST['submit'])){
                            $Title = htmlspecialchars($_POST['title']);
                            $Insert1 = mysqli_query($config,"UPDATE General SET general_value = '$Title' WHERE general_name = 'general_title'");
                            $Url = htmlspecialchars($_POST['url']);
                            $Insert2 = mysqli_query($config,"UPDATE General SET general_value = '$Url' WHERE general_name = 'general_url'");
                            $Logo = htmlspecialchars($_POST['logo']);
                            $Insert3 = mysqli_query($config,"UPDATE General SET general_value = '$Logo' WHERE general_name = 'general_logo'");
                            $owner = htmlspecialchars($_POST['owner']);
                            $Insert4 = mysqli_query($config,"UPDATE General SET general_value = '$owner' WHERE general_name = 'general_owner'");
                            $ownerlogo = htmlspecialchars($_POST['owner-logo']);
                            $Insert5 = mysqli_query($config,"UPDATE General SET general_value = '$ownerlogo' WHERE general_name = 'general_owner_logo'");
                            $header = $_POST['header'];
                            $Insert6 = mysqli_query($config,"UPDATE General SET general_value = '$header' WHERE general_name = 'general_header'");
                            $footer = $_POST['footer'];
                            $Insert7 = mysqli_query($config,"UPDATE General SET general_value = '$footer' WHERE general_name = 'general_footer'");
                            $About = $_POST['about'];
                            $Insert8 = mysqli_query($config,"UPDATE General SET general_value = '$About' WHERE general_name = 'general_about'");
                            $privacy = $_POST['privacy'];
                            $Insert9 = mysqli_query($config,"UPDATE General SET general_value = '$privacy' WHERE general_name = 'general_privacy'");
                            $terms = $_POST['terms'];
                            $Insert10 = mysqli_query($config,"UPDATE General SET general_value = '$terms' WHERE general_name = 'general_terms'");
                            $contact = $_POST['contact'];
                            $Insert11 = mysqli_query($config,"UPDATE General SET general_value = '$contact' WHERE general_name = 'general_contact'");
                            $meta = $_POST['meta-tag'];
                            $Insert11 = mysqli_query($config,"UPDATE General SET general_value = '$meta' WHERE general_name = 'general_meta_tag'");
                            echo '<p class="alert alert-success">Settings saved. Refresh......</p>';
                            echo '<script>setTimeout(function(){ window.location.replace(window.location.href); }, 1000);</script>';
                            }
                        ?>
                        <form method="post">
                        <div class="row gy-4">
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="title" placeholder="Helixs Online Tools" value="<? echo $general_title['general_value']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Website Title</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="url" name="url" placeholder="https://tools.helixsid.today" value="<? echo $general_url['general_value']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Website URL</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="logo" placeholder="https://www.helixsid.today/Logo.png" value="<? echo $general_logo['general_value']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Logo</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="owner" placeholder="Helix" value="<? echo $general_owner['general_value']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Website Owner</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="owner-logo" placeholder="Owner Logo" value="<? echo $general_owner_logo['general_value']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Owner Logo</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text" name="contact" placeholder="Contact" value="<? echo $general_contact['general_value']; ?>" class="form-control form-control-xl form-control-outlined" id="outlined-right-icon">
                                        <label class="form-label-outlined" for="outlined-right-icon" >Contact</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                    <div class="form-control-wrap">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-<? echo $general_body_color['general_value']; ?>">Header Script</span>
                                            </div>
                                            <textarea placeholder="Header Script" class="form-control" rows="10" cols="80" name="header"><? echo htmlspecialchars($general_header['general_value']); ?></textarea>
                                        </div>
                                    </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                    <div class="form-control-wrap">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-<? echo $general_body_color['general_value']; ?>">Footer Script</span>
                                            </div>
                                            <textarea placeholder="Footer Script" class="form-control" rows="10" cols="80" name="footer"><? echo $general_footer['general_value']; ?></textarea>
                                        </div>
                                    </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                    <div class="form-control-wrap">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-<? echo $general_body_color['general_value']; ?>">Meta Tag Script</span>
                                            </div>
                                            <textarea placeholder="Footer Script" class="form-control" rows="10" cols="80" name="meta-tag"><? echo $general_meta_tag['general_value']; ?></textarea>
                                        </div>
                                    </div>
                            </div>
                            <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">About</h4>
                                                <div class="nk-block-des">
                                                    <p class="text-danger">Note : Upload Image Akan Membuat Website Sedikit Melambat, Di Sarankan Untuk Insert Link Image Saja</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-bordered">
                                            <div class="card-inner">
                                                <textarea class="summernote-basic" name="about"><? echo $general_about['general_value']; ?></textarea>
                                            </div>
                                        </div>
                            </div>
                            <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Privacy Policy</h4>
                                                <div class="nk-block-des">
                                                    <p class="text-danger">Note : Upload Image Akan Membuat Website Sedikit Melambat, Di Sarankan Untuk Insert Link Image Saja</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-bordered">
                                            <div class="card-inner">
                                                <textarea class="summernote-basic" name="privacy"><? echo $general_privacy['general_value']; ?></textarea>
                                            </div>
                                        </div>
                            </div>
                            <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Terms & Conditions</h4>
                                                <div class="nk-block-des">
                                                    <p class="text-danger">Note : Upload Image Akan Membuat Website Sedikit Melambat, Di Sarankan Untuk Insert Link Image Saja</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-bordered">
                                            <div class="card-inner">
                                                <textarea class="summernote-basic" name="terms"><? echo $general_terms['general_value']; ?></textarea>
                                            </div>
                                        </div>
                            </div>
                        </div>
                        <br>
                            <div class="form-group text-center">
                                <button type="submit" name="submit" class="btn btn-info btn-fill btn-wd">Save</button>
                            </div>
                            </form>
                            
                            
                    </div>
                </div>
            </div>
        </div>
</div>
                        </div>
                    </div>
                </div>
                <link rel="stylesheet" href="./assets/css/editors/summernote.css?ver=2.4.0">
    <script src="./assets/js/libs/editors/summernote.js?ver=2.4.0"></script>
    <script src="./assets/js/editors.js?ver=2.4.0"></script>
                <!-- content @e -->
<?php } else {
    http_response_code(404);
} ?>
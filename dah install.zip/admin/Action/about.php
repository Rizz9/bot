<?php if (isset($_SESSION['id']) === true) { ?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-<? echo $general_body_color['general_value']; ?>">
                            <h5 class="title">About</h5>
                    </div>
                    <div class="card-body">
                            <strong>Secret Code</strong>
                            <pre><?php echo $general_secret_code['general_value']; ?></pre>
                            <strong>Domain</strong>
                            <pre><?php echo $_SERVER["SERVER_NAME"]; ?></pre>
                            <strong>allow_url_fopen </strong>
                            <pre><?php if(ini_get('allow_url_fopen')){ echo "<p class='text-success'>ON</p>";} else{ echo "<p class='text-danger'>OFF</p>";} ?></pre>
                            <strong>PDO </strong>
                            <pre><?php if(defined('PDO::ATTR_DRIVER_NAME')){ echo "<p class='text-success'>ON</p>";} else{ echo "<p class='text-danger'>OFF</p>";} ?></pre>
                            <strong>Port</strong>
                            <pre><?php echo $_SERVER["SERVER_PORT"]; ?></pre>
                            <strong>PHP Version</strong>
                            <pre><?php echo PHP_VERSION; ?></pre>
                            <strong>CURL Version</strong>
                            <pre><?php $curl = curl_version(); echo $curl['version']; ?></pre>
                            <strong>Web Server</strong>
                            <pre><?php echo $_SERVER["SERVER_SOFTWARE"]; ?></pre>
                            <strong>Server IP</strong>
                            <pre><?php echo $_SERVER["SERVER_ADDR"]; ?></pre>
                            <strong>Operating System</strong>
                            <pre><?php echo php_uname(); ?></pre>
                            <strong>MySQL</strong>
                            <pre><?php if(function_exists('mysql_get_client_info')||class_exists('mysqli')) {
$mysql='ON';}
else{
$mysql='OFF';} echo $mysql; ?></pre>

<strong>MSSQL</strong>
                            <pre>
<?php if(function_exists('mssql_connect')) {
$mssql='ON';}
else{
$mssql='OFF';} echo $mssql; ?></pre>

<strong>PostgreSQL</strong>
                            <pre>
<?php if(function_exists('pg_connect')) {
$pg='ON';}
else{
$pg='OFF';} echo $pg; ?></pre>

<strong>Oracle</strong>
                            <pre>
<?php if(function_exists('oci_connect')) {
$pg='ON';}
else{
$pg='OFF';} echo $pg; ?></pre>

<strong>Safe Mode</strong>
                            <pre>
<?php if(@ini_get('disable_functions'))
$disfun=@ini_get('disable_functions');
else
$disfun="All Functions Enable";
if(@ini_get('safe_mode'))
$safe_modes="<p class='text-success'>ON</p>";
else
$safe_modes="<p class='text-danger'>OFF</p>"; echo $safe_modes; ?></pre>
<strong>Disable Function</strong>
                            <pre>
<?php if(@ini_get('disable_functions')){
$disfun=@ini_get('disable_functions');}
else {
$disfun="<p class='text-success'>All Functions Enable</p>";} echo $disfun; ?></pre>
                    
                </div>
            </div>
        </div>
</div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
<?php } else {
    http_response_code(404);
} ?>
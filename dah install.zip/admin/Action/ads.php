<?php if (isset($_SESSION['id']) === true) { ?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-<? echo $general_body_color['general_value']; ?>">
                        <h5 class="title">Advertising</h5>
                    </div>
                    <div class="card-body">
                        <?php
                            if(isset($_POST['submit'])){
                            $Ads1 = $_POST['ADS1'];
                            $Ads2 = $_POST['ADS2'];
                            $Ads3 = $_POST['ADS3'];
                            $Ads4 = $_POST['ADS4'];
                            $Insert1 = mysqli_query($config,"UPDATE General SET general_value = '$Ads1' WHERE general_name = 'ads1'");
                            $Insert2 = mysqli_query($config,"UPDATE General SET general_value = '$Ads2' WHERE general_name = 'ads2'");
                            $Insert3 = mysqli_query($config,"UPDATE General SET general_value = '$Ads3' WHERE general_name = 'ads3'");
                            $Insert4 = mysqli_query($config,"UPDATE General SET general_value = '$Ads4' WHERE general_name = 'ads4'");
                            echo '<p class="alert alert-success">Settings saved. Refresh......</p>';
                            echo '<script>setTimeout(function(){ window.location.replace(window.location.href); }, 1000);</script>';
                            }
                        ?>
                        <form method="post">
                                    <div class="form-control-wrap">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-<? echo $general_body_color['general_value']; ?>">Ad Area 1 <br>(Index Page)</span>
                                            </div>
                                            <textarea placeholder="Paste your ad code" id="ads_1" class="form-control" rows="10" cols="80" name="ADS1"><? echo $ads1['general_value']; ?></textarea>
                                        </div>
                                    </div>
                                <br>
                                    <div class="form-control-wrap">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-<? echo $general_body_color['general_value']; ?>">Ad Area 2 <br>(Sidebar) </span>
                                            </div>
                                        <textarea placeholder="Paste your ad code" id="ads_2" class="form-control" rows="10" cols="80" name="ADS2"><? echo $ads2['general_value']; ?></textarea>
                                        </div>
                                    </div>
                                <br>
                                    <div class="form-control-wrap">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-<? echo $general_body_color['general_value']; ?>">Ad Area 3 <br>(Under Tools)</span>
                                            </div>
                                            <textarea placeholder="Paste your ad code" id="ad_area_3" class="form-control" rows="10" cols="80" name="ADS3"><? echo $ads3['general_value']; ?></textarea>
                                        </div>
                                    </div>
                                <br>        
                                    <div class="form-control-wrap">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text bg-<? echo $general_body_color['general_value']; ?>">Ad Area 4 <br>(Footer)</span>
                                            </div>
                                            <textarea placeholder="Paste your ad code" id="ads_4" class="form-control" rows="10" cols="80" name="ADS4"><? echo $ads4['general_value']; ?></textarea>
                                        </div>
                                    </div>
                                <br>
                            <div class="form-group text-center">
                                <button type="submit" name="submit" class="btn btn-info btn-fill btn-wd">Save</button>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
</div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
<?php } else {
    http_response_code(404);
} ?>
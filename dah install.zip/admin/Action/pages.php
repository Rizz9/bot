<?php if (isset($_SESSION['id']) === true) { ?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-<? echo $general_body_color['general_value']; ?>">
                        <h5 class="title">All Pages</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        if(isset($_GET['delete'])){
                            $delete_id = $_GET['delete'];
                            $Deleting = mysqli_query($config,"DELETE FROM contents WHERE ID = '$delete_id'");
                            echo '<script>Swal.fire("Deleted!", "Your file has been deleted.", "success");</script>';
                            echo '<p class="alert alert-success">Pages Deleted. Refresh......</p>';
                            echo '<script>setTimeout(function(){ window.location.href = "admin.php?Pages"; }, 1000);</script>';
                            }
                            ?>
                        <div class="nk-block nk-block-lg">
                            <div class="toggle-expand-content expanded" data-content="All-files">
                                <div class="nk-files nk-files-view-group">  
                                        <div class="card card-preview">
                                            <div class="card-inner">
                                                <table class="datatable-init table">
                                                    <thead>
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>Title</th>
                                                            <th>Lihat</th>
                                                            <th>Edit</th>
                                                            <th>Delete</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                                        <?php
                $resultData = mysqli_query($config, "SELECT * FROM contents ORDER BY ID");
                while ($rowData = mysqli_fetch_array($resultData)) {
                 ?>
                 
                                                        <tr>
                                                            <td><?= $rowData['ID']; ?></td>
                                                            <td><?= $rowData['content_title']; ?></td>
                                                            <td><a href="../home/?pages=<?= $rowData['content_slug']; ?>" target="_blank" class="btn btn-icon btn-round btn-dim btn-outline-primary"><em class="icon ni ni-eye"></em></a></td>
                                                            <td><a href="./admin.php?Pages-Edit=<?= $rowData['ID']; ?>"><button class="btn btn-icon btn-round btn-dim btn-outline-primary"><em class="icon ni ni-edit"></em></button></a></td>
                                                            <td><a href="./admin.php?Pages&delete=<?= $rowData['ID']; ?>"><button class="btn btn-icon btn-round btn-dim btn-outline-primary"><em class="icon ni ni-trash-empty-fill"></em></button></a></td>
                                                        </tr>
                                                        <? } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    </div><br>
                                <center><a href="./admin.php?Pages-Create"><button class="btn btn-outline-primary">Create Pages</button></a> </center>   
                        
                    </div>
                </div>
            </div>
        </div>
</div>
                        </div>
                    </div>
                </div>
    
                <!-- content @e -->
<?php } else {
    http_response_code(404);
} ?>

        <center>
            <input class="form-control text-danger" id="text" placeholder="Text/Link"/>
            <br><br>
            <select class="form-control text-danger" id="type">
                <option value="">Text</option>
                <option value="http://">Link</option>
                <option value="tel%3A">Call</option>
            </select>
            &nbsp;&nbsp;
            <br>
            <button class="btn btn-outline-warning" onclick="make()">Buat!</button>
            <br><br>
            <img :src="" id="qr"/>
        </center>
 
<script>

    var type=document.getElementById("type");
    var text=document.getElementById("text");
    var qr=document.getElementById("qr");
        
    function make() {
        var x=text.value;
        var y=type.value;
        var lin=document.getElementById("lin");
            qr.src="https://api.qrserver.com/v1/create-qr-code/?data="+y+x+"&size=280x280&margin=1";
            lin.href="http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data="+y+x+"&qzone=1&margin=1&size=280x280&ecc=L&download=1";} 

</script>
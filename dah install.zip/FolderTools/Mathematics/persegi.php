

                          <?php 
    @$sisi = htmlspecialchars($_POST['sisi']);
    @$keliling = 4 * $sisi;
    @$luas = $sisi * $sisi;
?>
        <form  method="POST">
            s (sisi) = 
            <input type="text" class="form-control text-primary" name="sisi" value="<?php echo $sisi; ?>"/><br/>
            <input type="submit" class="btn btn-outline-primary" name="submit" value="SUBMIT"/><br/><br/>
            <?php
                echo "Keliling Persegi = ".$keliling," cm<br>";
                echo "Luas Persegi = ".$luas." cm<sup>2</sup><br/>";
            ?>
        </form>
                       
            
<form method="post">
            <input type="text" class="form-control" name="start" placeholder="Start IPs" value="62.171.151.245"><br>
            <input type="text" class="form-control" name="end" placeholder="End IPs" value="62.171.152.245"><br>
            <button type="submit" name="submit" class="btn btn-round btn-dim btn-outline-info">Submit</button>
</form>
<?php
if(isset($_POST['submit'])){
$start = $_POST['start'];
$end = $_POST['end'];
$url = $general_url['general_value'];
$ipss = file_get_contents("$url/API/IPs.php?start=$start&end=$end");
$ips = explode("\r\n",$ipss);
echo '<br><center><p class="text-success">Valid IP</p></center><textarea name="site" cols="50" class="form-control" rows="10">';
foreach($ips as $lala){
$Cek = "https://networkappers.com/api/port.php?ip=".$lala."&port=80";
$ch = curl_init($Cek);
$headers = [
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0',	
    'Accept: application/json, text/javascript, /; q=0.01',   
    'Accept-Language: id,en-US;q=0.7,en;q=0.3',    
    'X-Requested-With: XMLHttpRequestConnection: keep-alive',
    'Connection: keep-alive',    
    'Referer: https://networkappers.com/tools/open-port-checker'
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 3);
$output = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if (strpos($output,'open'))
{
echo  $lala."\r\n";
}
}
echo "</textarea>";
}?>
<br>
<div class="alert alert-danger">
    Tools Ini Akan Bekerja jika Start IPs dan End IPs Valid, Lalu Tools Akan Membuat IP Dari  <? echo $general_url['general_value']."/API/IPs.php" ?> dan Melakukan Validasi IP dari List IP yang di Buat Oleh API Tadi
</div>


                  
                <form action="" method="POST">
                  <textarea name="site" cols="50" class="form-control text-light" rows="10" placeholder="https://namaweb.sites"></textarea>
                  <br>
<input type="submit" class="btn btn-outline-warning" name="au" value="Scan CMS">
</center><hr>

<?php

function send($url){
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $output = curl_exec($ch);
  curl_close($ch);
  return $output;
}

function detect($site){
  $send = send($site);
if(preg_match('/\/wp-content\/|\/wp-includes\/|\/xmlrpc.php/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ WordPress ]</b> : $site</b><br></div>";
}
elseif(preg_match('/<script type=\"text\/javascript\" src=\"\/media\/system\/js\/mootools.js\"><\/script>|Joomla|\/media\/system\/js\/|mootools-core.js|com_content|Joomla!/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Joomla]</b> : $site</b><br></div>";
    }
elseif(preg_match('/\/faq.php\/vb|\/clientscript\/|vBulletin|vbulletin/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ vBulletin ]</b> : $site</b><br></div>";
  }
elseif(preg_match('/Drupal|drupal|sites\/all|drupal.org/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Drupal]</b> : $site</b><br></div>";
    }
elseif(preg_match('/\/skin\/frontend\/base\/default\/|\/\/magentocore.net\/mage\/mage.js|\/webforms\/index\/index\/|\/customer\/account\/login/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Magento ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/route=product|OpenCart|route=common|catalog\/view\/theme/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ OpenCart ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/zcadmin\/login.php|zcadmin|zencart/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ ZenCart ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/\/collections\/all|Powered by Shopify|\/\/cdn.shopify.com\//',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Shopify ]</b> : $site</b><br></div>";
    }

elseif(preg_match('/xenforo|XenForo|uix_sidePane_content/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ XenForo ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/semua-agenda.html|foto_banner\/|lokomedia/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Lokomedia ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/typo3|TYPO3|Typo3/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Typo3 ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/filemanager.php|filemanager|fileman|\/assets\/global\/plugins\/|\/assets\/plugins\/|\/assets\/public\/plugins\/|\/assets\/private\/plugins\/|\/assets\/admin|\/admin\/plugins\/|assets\/dashboard\//',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Responsive FileManager ]</b> : $site</b><br></div>";
    } 
elseif(preg_match('/upload.php|admin.php|administrator.php|upload file|input type=\"file\"/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Weak Website ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/porn|blowjob/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Bokep ]</b> : $site</b><br></div>";
    }
elseif(preg_match("/\/feeds\/posts\/default?alt=rss|meta content=\'blogger\' name=\'generator\'/",$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Blogger ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/Liferay|liferay/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Liferay ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/Wolf|Wolf CMS|\?admin/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Wolf CMS ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/timthumb|\/tim.php|\/thumb.php|\/foto.php/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Timthumb ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/Index of|Last modified/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Web Rusak ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/mcc.godaddy.com\/park\/|domain has expired|Domain Expired|domain expired|Undermainteance|mcc.godaddy.com|Under Construction|Construction|expired/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Web Expired ]</b> : $site</b><br></div>";
    }
elseif(preg_match('/html|head|body/',$send)) {
    echo "<div class='alert alert-info'><b class='text-success'><b><font face=courier><center> [ Web Biasa ]</b> : $site</b><br></div>";
    }
else{
    echo "<div class='alert alert-danger'><b class='text-success'><b><font face=courier><center> [ Unknown ]</b> : $site</b><br></div>";
}
}
if(isset($_POST['au'])){
$er = explode("\r\n",$_POST['site']);
  echo "<br>";
foreach($er as $sites){
  echo detect($sites);
}
}

?>

          <table class="table table-bordered table-striped">
    <thead>
  <center>
 <?php

if(!isset($_POST['Submit']))
{
	echo "Masukkan Domain,Jangan Menggunakan <strong>www.</strong><br>";
    echo '<form method="POST" action="">'
            . '<input type="text" class="form-control text-danger" name="domains" style="color:black;"><br />'
            .'<br>'
            . '<input type="submit" name="Submit" class="btn btn-outline-info" value="Cek">'
            . '</form>';
}
else
{
    $domains = htmlspecialchars(explode("\n", str_replace(array("\r\n", "\r"), "\n", $_POST['domains'])));
    
    foreach($domains as $domain)
    {
        if(is_avail($domain))
        {
            $pieces = explode(".", $domain, 1);
            echo $domain . "<strong> Domain Tersediaa! Register <a href='https://anymhost.id'>Sekarang</a></strong><br/>";
        }
		else
		{
			echo $domain . "<strong> Domain Tidak Tersediaa</strong><br/>";
		}
    }
}

function is_avail($domain)
{    
    $pieces = explode(".", $domain);
    $server = (count($pieces) == 2) ? $pieces[1] : $pieces[1] . "." . $pieces[2];
    $server .= ".whois-servers.net";
    $fp = fsockopen($server, 43, $errno, $errstr, 10);
    $result = "";
    if($fp === FALSE){ return FALSE; }
    fputs($fp, $domain . "\r\n");    
    while(!feof($fp)){ $result .= fgets($fp, 128); }
    fclose($fp);
    
    return ((stristr($result, 'no match for') !== FALSE) || (strtolower($result) == "notfound\n")) ? TRUE : FALSE;
}

?> 
	</table>
	</center>
	</a>
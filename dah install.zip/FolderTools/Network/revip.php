<center>
      <form action="" method="POST">
        Domain:<br>
        <input type="text" class="form-control text-danger" rows="10" cols="90" name="sitem">
        <br><br>
        <input type="submit" class="btn btn-outline-primary" name="reverse" value="Reverse" />
      </form>
<br>
<?php
//$_POST["sitem"];
//$_POST["reverse"];
$ch = curl_init("https://api.hackertarget.com/reverseiplookup/?q=".$_POST["sitem"]."&t=1");
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_NOBODY, 0);
$whois = curl_exec($ch);

echo '<textarea name="result" id="result" class="form-control text-dark" rows="7">'.$whois.'</textarea>';
curl_close($ch);
?></center>
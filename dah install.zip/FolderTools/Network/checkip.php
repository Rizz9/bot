
          	<table class="table table-bordered table-striped">
		<thead>
		<p>Domain:&nbsp;&nbsp;&nbsp;</p>
        <form method="POST" action="">
		<input type="text" name="file" class="form-control text-danger" autocomplete="off" placeholder="4dh4x0r.id" value="<?php htmlspecialchars(@$_POST['file'])?>" /><br> 
		<input type="submit" class="btn btn-outline-primary" value="Go" /></thead>
        </form>
</div>
<?php
if (isset($_POST['file']) && !empty($_POST['file'])) {
	$i = 0;
	$filter = htmlspecialchars($_POST['file']);
	$exp = explode("\n", $filter);
	echo "<br><label>IP : </label><br>";
	foreach ($exp as $key) {
		if(!preg_match('#^http(s)?://#',$key)){
			$a = "http://".$key;
		}
		else {
			$a = $key;
		}
		$parse = parse_url($a);
		$domain = preg_replace('/^www\./', '', $parse['host']);
		$fuck = preg_replace('/_/', '', $domain);
		$www = "www.".$fuck;
		$host = gethostbyname($www);
		while ($host > $i) {
			echo $host."\n";
			$i++;
			break;
		}
	}
}?>
	</table>
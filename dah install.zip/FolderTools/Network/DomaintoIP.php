
          
          <form action="" method="POST">
		<b class="text-danger">Note :  List domain.com - Max 500 domain agar tidak overload<br>
		<textarea rows="10" cols="60" class="form-control" name="file" placeholder="Your Site"></textarea><br>
		<input type="submit" class="btn btn-primary btn-block" value="Mass domain to IP">
	</form><br>
<?php
if (isset($_POST['file']) && !empty($_POST['file'])) {
	$i = 0;
	$filter = htmlspecialchars($_POST['file']);
	$exp = explode("\n", $filter);
	echo "<br><label>List Ip : </label><br>";
	echo "<textarea id='output' class='form-control' rows='10' cols='60'>";
	foreach ($exp as $key) {
		if(!preg_match('#^http(s)?://#',$key)){
			$a = "http://".$key;
		}
		else {
			$a = $key;
		}
		$parse = parse_url($a);
		$domain = preg_replace('/^www\./', '', $parse['host']);
		$fuck = preg_replace('/_/', '', $domain);
		$www = "www.".$fuck;
		$host = gethostbyname($www);
		while ($host > $i) {
			echo $host."\n";
			$i++;
			break;
		}
	}
	echo '</textarea><br>			<button type="button" onclick="salin()" class="btn btn-success btn-block"><i class="fas fa-clone"></i></button>';
}
?>
<script>
    		function salin() {
			document.getElementById("output").select();
			document.execCommand("copy");
			            		Swal.fire({
					  	title: 'Berhasil',
					  	text: 'Text Berhasil Disalin',
					})
		}
</script>

                
      <?php
        $url = "";
        if(!empty($_REQUEST["url"])){
           $url = $_REQUEST["url"];
        }
        
        $methode = "post";
        if(!empty($_REQUEST["methode"])){
           $methode = $_REQUEST["methode"];
        }
      ?>
      
      
      <form  method="POST">
          <div class="form-group">
           <div class="input-group">
             <input type="url" class="form-control text-danger" placeholder="off" name="url" value="<?php echo $url; ?>" placeholder="url" />
                <input type="submit"  class="btn btn-primary" value="Go">
           </div>
          </div>
          
          <div class="form-group row">
              <label class="col-sm-2 control-label">Request-Type: </label>
                <div class="col-sm-10">
                    <label class="radio-inline">
                        <input type="radio" name="methode"  <?php echo ($methode == "get"? 'checked="checked"': ''); ?> value="get"> GET
                    </label>
                    <label class="radio-inline">
                      <input type="radio" name="methode"  <?php echo ($methode == "post"? 'checked="checked"': ''); ?> value="post"> POST
                    </label>
                    <label class="radio-inline">
                      <input type="radio" name="methode"  <?php echo ($methode == "put"? 'checked="checked"': ''); ?> value="put"> PUT
                    </label>
                </div>
          </div>
          
      </form>
    
      <?php
            if(!empty($_SESSION["last_check"]) && $_SESSION["last_check"] > time() - 5){
                $url = "";
                
                echo '<div class="container">'
                    . '<div class="alert alert-danger" role="alert">Only one check per 5 Sec enable. Wait a Moment and try it again.</div>'
                    . '</div>';
            } else {
                $_SESSION["last_check"] = time();
            }
          ?>
          

      <?php if($url){ ?>
      <div class="container">
          
          <?php
            $time_start = microtime(TRUE);

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, true);
            
            if($methode == "post"){
                curl_setopt($ch, CURLOPT_POST, true);
            } elseif ($methode == "put"){
                curl_setopt($ch, CURLOPT_PUT, true);
            }

            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $time_end = microtime(TRUE);
            $time_diff = ($time_end - $time_start);
            
            list($header, $body) = explode("\r\n\r\n", $response, 2);
         ?>
          
          <div class="panel panel-default">
            <div class="panel-heading">INFO</div>
            <div class="panel-body">
              <hr>
              <?php
                echo "<ul>";
                echo "<li><strong>url:</strong> ".$url."</li>";
                echo "<li><strong>Time:</strong> ".$time_diff." sec</li>";
                echo "<li><strong>Http-Status:</strong> ".$httpcode."</li>";
                echo "</ul>";
              ?>
            </div>
          </div>
          </hr>
          <div class="panel panel-default">
            <div class="panel-heading">Header</div>
            <div class="panel-body">
              <hr>
              <?php
                echo "<ul>";
                foreach (explode("\r\n", $header) as $i => $line)
                        {
                            list ($key, $value) = explode(': ', $line);
                            echo "<li><strong>{$key}:</strong> {$value}</li>";
                        }
                echo "</ul>";
              ?>
            </div>
          </div>
      </hr>
      
          <div class="panel panel-default">
            <div class="panel-heading">Content</div>
            <div class="panel-body">
              <hr>
               <textarea class="form-control" id="html">
                    <?php
                        echo htmlspecialchars($body);
                    ?>
               </textarea>
            </div>
          </div>
          </hr>
      </div>
      <?php } ?>
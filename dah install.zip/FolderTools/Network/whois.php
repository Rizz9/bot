<?php
   @set_time_limit(0);
   @error_reporting(0);
   function sws_domain_info($site)
   {
   $getip = @file_get_contents("http://networktools.nl/whois/$site");
   flush();
   $ip = @findit($getip,'<pre>','</pre>');
   return $ip;
   flush();
   }
   function sws_net_info($site)
   {
   $getip = @file_get_contents("http://networktools.nl/asinfo/$site");
   $ip = @findit($getip,'<pre>','</pre>');
   return $ip;
   flush();
   }
   function sws_site_ser($site)
   {
   $getip = @file_get_contents("http://networktools.nl/reverseip/$site");
   $ip = @findit($getip,'<pre>','</pre>');
   return $ip;
   flush();
   }
   function sws_sup_dom($site)
   {
   $getip = @file_get_contents("http://www.magic-net.info/dns-and-ip-tools.dnslookup?subd=".$site."&Search+subdomains=Find+subdomains");
   $ip = @findit($getip,'<strong>Nameservers found:</strong>','<script type="text/javascript">');
   return $ip;
   flush();
   }
   function sws_port_scan($ip)
   {
   $list_post = array('80','21','22','2082','25','53','110','443','143');
   foreach ($list_post as $o_port)
   {
   $connect = @fsockopen($ip,$o_port,$errno,$errstr,5);
   if($connect)
   {
   echo " $ip : $o_port ??? <u style=\"color: #00ff00\">Open</u> <br /><br />";
   flush();
   }
   }
   }
   function findit($mytext,$starttag,$endtag) {
   $posLeft = @stripos($mytext,$starttag)+strlen($starttag);
   $posRight = @stripos($mytext,$endtag,$posLeft+1);
   return @substr($mytext,$posLeft,$posRight-$posLeft);
   flush();
   }
?>
<center>
    <form method="post">
    <input type="text" name="site" class="form-control" value="site.com">
    <br>
    <input class="btn btn-outline-dark" type="submit" name="scan" value="Scan !">
    </form>
</center>
<?
   if(isset($_POST['scan']))
   {
   $site = @htmlentities($_POST['site']);
   if (empty($site)){die('<br /><br /> Not add IP .. !');}
   $ip_port = @gethostbyname($site);
   echo "
   <br><h5 class='text-success'>Scanning [ $site ip $ip_port ] ... </h5><br>
   <center><h5 class='text-success'>|<<<<[ Port Server ]>>>>|</h5><br>";
   echo "<pre>".sws_port_scan($ip_port)."</pre></center><br>";
   flush();
   echo "<center><h5 class='text-success'>|<<<<[ Domain Info ]>>>>|</h5><br>
   <textarea class='form-control' readonly>".sws_domain_info($site)."</textarea><br>";
   flush();
   echo "
   <center><h5 class='text-success'>|<<<<[ Network Info ]>>>>|</h5><br>
   <textarea class='form-control' readonly>".sws_net_info($site)."</textarea><br>";
   flush();
   echo "<center><h5 class='text-success'>|<<<<[ Subdomains on Server ]>>>>|</h5><br>
   <textarea class='form-control' readonly>".sws_sup_dom($site)."</textarea><br>";
   flush();
   echo "<center><h5 class='text-success'>|<<<<[ Site Server ]>>>>|</h5><br>
   <textarea class='form-control' readonly>".sws_site_ser($site)."</textarea>
   <br /><br />|-------------- END ------------------| <br />";
   flush();
   }
   
?>
<center>
              <script>
		function salin() {
		    document.getElementById("output").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
}
	</script>
    <form method="post">
    <input type="date" name="date" class="form-control date-picker-alt" data-date-format="yyyy-mm-dd" placeholder="Date"><br>
    <input type="number" name="page" class="form-control" placeholder="Page"><br>
    <button type="submit" class="btn btn-outline-danger btn-dim">Submit</button>
    <button type="button" onclick="salin()" class="btn btn-outline-success btn-dim ">Salin <i class="fas fa-clone"></i></button><br>
</form>
<?php
$date = $_POST['date'];
$page = htmlspecialchars($_POST['page']);
$url = $general_url['general_value'];
    $json = file_get_contents($url.'/API/grabbydate.php?date='.$date.'&page='.$page.'');
	$data = json_decode($json, true);
	if($data["status"] == 'success'){
	$result = $data["result"];
	echo "<br><div class='alert alert-success'>Grab Result From Date ".$date;
	echo " and Pages ".$page."</div>";
		echo"<br><textarea class='form-control' id='output' placeholder='Result'>".implode('&#13;&#10;',$result)."</textarea>";
	} else{
	    echo"<br><textarea class='form-control' id='output' placeholder='Result'>NULL</textarea>";
	}
		?>
		</center>
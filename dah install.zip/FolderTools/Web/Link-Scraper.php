
          
<form method="post" action="">
<p>Link: <input type="url" class="form-control" name="url" id="url"><br>
              <input type="submit" name="submit" class="btn btn-outline-warning" value="Get"></p>
</form>

 <?php
	$request_url = htmlentities($_POST['url']);

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $request_url);	// The url to get links from
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);	// We want to get the respone
	$result = curl_exec($ch);
 
	$regex='|<a.*?href="(.*?)"|';
	preg_match_all($regex,$result,$parts);
	$links=$parts[1];
	foreach($links as $link){
	    $linkk = str_replace($request_url,"","$link");
		echo "<div class='alert alert-success'><a href='". $linkk ."' target='_blank'>" . $linkk ."<br></a></div>";
	}
	curl_close($ch);
?>
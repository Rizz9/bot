
          <center>
<form method="post"><br>
<select class='form-control text-danger' name="from">
<option value="archive">archive</option>
<option value="special">special</option>
<option value="onhold">onhold</option>
</select> <br>
<input class='form-control text-danger' type='number'  name='page' placeholder="Max Page 50"><br>
<input class='btn btn-outline-danger' type='submit'  name='submit' value='GRAB'>
</form></center><br>
<?php
if (isset($_POST['submit'])) {
    echo "<textarea rows='10' cols='90' class='form-control'>";
    $from = $_POST['from'];
    $page = $_POST['page'];
    $url = $general_url['general_value'];
    $Result = file_get_contents(''.$url.'/API/haxorid.php?from='.$from.'&pages='.$page.'&text');
    echo $Result."</textarea>";
}
?>

<center>
<form method="POST">
					    <input type="text" class="form-control" name="name" placeholder="File Name"><br>
		<textarea name="site" class="form-control" placeholder="Url List" rows="8"></textarea><br>
			<input type="submit" class="btn btn-round btn-dim btn-outline-success" name="submit" value="Submit"><br>
			</form><br>
			
			<?php
if(isset($_POST['submit'])){
$name = $_POST['name'];
$pass = explode("\r\n",$_POST['site']);
$site1 = str_replace("http://","",$pass);
$site = str_replace("https://","",$site1);
echo "<textarea rows='10' cols='90' class='form-control'>";
  foreach ($site as $sites) {
      $result = "https://" . $sites."/".$name . "\n";
      echo $result;
}
echo "</textarea>";
}
?>
</center>
<center>
              <script>
		function salin() {
		    document.getElementById("output").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
}
	</script>
    <form method="post">
    <textarea class="form-control" name="url" placeholder="URL List"></textarea><br>
    <button type="submit" class="btn btn-outline-danger btn-dim">Submit</button>
    <button type="button" onclick="salin()" class="btn btn-outline-success btn-dim ">Salin <i class="fas fa-clone"></i></button><br>
</form>
<?php
$urls = $_POST['url'];
$url = $general_url['general_value'];
	$Mass = explode("\n", $urls);
	echo "<br><textarea class='form-control' id='output' placeholder='Result'>";
	foreach($Mass as $Masss) {
    $json = file_get_contents($url.'/API/email.php?url='.$Masss);
	$data = json_decode($json, true);
	if($data["status"] = 'success'){
	$result = $data["result"];
		echo implode('&#13;&#10;',$result)."&#13;&#10;";
	} else{
	    echo"Bad";
	}
	}
	echo "</textarea>";
		?>
		</center>
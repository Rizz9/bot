
          <center>
<form method="post"><br>
<select class='form-control text-danger' name="from">
<option value="archive">archive</option>
<option value="special">special</option>
<option value="onhold">onhold</option>
</select> <br>
<input class='form-control text-danger' type='number'  name='page' placeholder="Max Page 50"><br>
<input class='btn btn-outline-danger' type='submit'  name='submit' value='GRAB'>
</form></center><br>
<?php
if (isset($_POST['submit'])) {
    echo "<textarea rows='10' cols='90' class='form-control'>";
    $from = $_POST['from'];
    $page = $_POST['page'];
    $url = $general_url['general_value'];
    $json = file_get_contents(''.$url.'/API/z-d.php?from='.$from.'&page='.$page.'');
	$data = json_decode($json, true);
	$i = 1;
	while ($i <= $page) {
if($data['status'] == "success") {
$result = $data["result-$i"];
		echo"".implode('&#13;&#10;',$result)."";
	}
		$i++;
		}echo "</textarea>";
}
?>

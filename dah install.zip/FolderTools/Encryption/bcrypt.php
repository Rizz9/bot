          <script>
		function salin() {
		    document.getElementById("output").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
}
	</script>
<?php
if(isset($_POST['submit'])){
    if($_POST['round'] > 18){
        echo '<div class="alert alert-danger">Round nya Kelebihan Woi!</div>';
    } else {
$options = [
	'cost' => $_POST['round'],
];

echo '<center><label>Hashed Password</label><input type="text" class="form-control" value="'.password_hash($_POST['input'], PASSWORD_BCRYPT, $options).'" id="output" readonly/><br>';
echo '<button type="button" onclick="salin()" class="btn btn-round btn-dim btn-outline-success">Salin <i class="fas fa-clone"></i></button><br>';
echo '<br><div class="alert alert-success">String : '.($_POST['input']).'</div></center><br>';
}
}
?>

        
<?php
if(isset($_POST['submit2'])){
$string1 = $_POST['hash'];
$string2 = $_POST['string'];
if(password_verify($string1, $string2)){
    echo '<div class="alert alert-success">String and Hash match!</div>';
} else{
    echo "<div class='alert alert-danger'>String and Hash do not match!</div>";
}
}
?>
<center>
        <form method="post">
            <label>Encrypt</label>
            <input type="text" class="form-control" name="input" placeholder="String to Bcrypt"><br>
            <input type="number" class="form-control" value="12" name="round" placeholder="Rounds"><br>
            <button type="submit" name="submit" class="btn btn-round btn-dim btn-outline-info">Submit</button>
            <br><br>
            <label>Decrypt</label>
            <input type="text" class="form-control" name="hash" placeholder="String to Check"><br>
            <input type="text" class="form-control" name="string" placeholder="Hashed Password"><br>
            <button type="submit" class="btn btn-round btn-dim btn-outline-success" name="submit2">Submit</button>
        </form>
</center>
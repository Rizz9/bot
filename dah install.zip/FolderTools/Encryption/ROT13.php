
<?php
$ROT13 = str_rot13($_POST['rot13']);
?>
<center>
<form action="" method="post" enctype="multipart/form-data">
<textarea rows="8" cols="65" name="rot13" class="form-control text-warning" placeholder="Encode Text"></textarea>
<br>
<input type="submit" class="btn btn-outline-warning" value="Encode or Decode Text" />
<button class="btn btn-outline-warning" onclick="myFunction()">Copy Text</button>
<form>
<br>    
<?php echo '<br><textarea class="form-control text-danger" id="HelixUwU" rows="8" cols="65">'.$ROT13.'</textarea>'; ?>
</center>

<script>
function myFunction() {
var copyText = document.getElementById("HelixUwU");
copyText.select();
copyText.setSelectionRange(0, 99999);
document.execCommand("copy");
alert("Helix UwU Success Copy " + copyText.value);
}
</script>
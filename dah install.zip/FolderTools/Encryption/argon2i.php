
          <script>
		function salin() {
		    document.getElementById("output").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
}
	</script>
<?php
if(isset($_POST['submit'])){
    $options = [
    'time_cost'   => $_POST['t'],
    'threads'     => $_POST['th'],
];
echo '<center><label>Hashed Password</label><input type="text" class="form-control" value="'.password_hash($_POST['text'], PASSWORD_ARGON2I,$options).'" id="output" readonly/><br>';
echo '<button type="button" onclick="salin()" class="btn btn-round btn-dim btn-outline-success">Salin <i class="fas fa-clone"></i></button><br>';
echo '<br><div class="alert alert-success">String : '.$_POST['text'].'</div></center><br>';
}
?>
<center>
        <form method="post">
    <input type="text" name="text" placeholder="Text" class="form-control"><br>
    <input type="number" name="t" placeholder="Iterations" value="1" class="form-control"><br>
    <input type="number" name="th" placeholder="Parallelism Factor" value="4" class="form-control"><br>
    <button type="submit" name="submit" class="btn btn-round btn-dim btn-outline-info">Submit</button>
        </form>
</center>

<form method="post"><br>
<textarea class="form-control text-danger" cols="auto" rows="10" name="code"></textarea><br><br>
<select class='form-control' name="ope">
<option><center>Choose Type</option>
                <option value="urlencode">url</option>
                <option value="www">chr</option>
                <option value="json">json</option>
                <option value="strlen">strlen</option>
                <option value="bbb">charAt</option>
                <option value="eee">escape</option>
                <option value="base64">base64</option>
                <option value="xxx">unescape</option>
                <option value="ur">convert_uu</option>
                <option value="str_rot13">ROT13 Hash</option>
                <option value="hexencode">Hex Enc-Dec</option>
                <option value="sss">htmlspecialchars</option>
                <option value="gzinflates">gzinflate - base64</option>
                <option value="str2">str_rot13 - base64</option>
                <option value="gzinflatess">base64 - gzcompress</option>
                <option value="aaa">chr - bin2hex - substr</option>
                <option value="gzinflate">str_rot13 - gzinflate - base64</option>
                <option value="gzinflater">gzinflate - str_rot13 - base64</option>
                <option value="gzinflatex">gzinflate - str_rot13 - gzinflate - base64</option>
                <option value="str">str_rot13 - gzinflate - str_rot13 - base64</option>
                <option value="url">base64 - gzinflate - str_rot13 - convert_uu - gzinflate - base64</option>
            
</select>
<br><br>
<center>
<input class='btn btn-outline-dark' type='submit'  name='submit' value='Encode'>
<input class='btn btn-outline-dark' type='submit' name='crack' value='Decode'>
<button class='btn btn-outline-dark' onclick="myFunction()">Copy Text</button>
</form></center><br><br>

<?php 
        $submit = $_POST['submit'];
        if (isset($submit)){
        $op = $_POST["ope"];
        switch ($op) {case 'base64': $codi=base64_encode($text);
        break;case 'str' : $codi=(base64_encode(str_rot13(gzdeflate(str_rot13($text)))));
        break;case 'gzinflate' : $codi=base64_encode(gzdeflate(str_rot13($text)));
        break;case 'json' : $codi=json_encode(utf8_encode($text));
        break;case 'gzinflater' : $codi=base64_encode(str_rot13(gzdeflate($text)));
        break;case 'gzinflatex' : $codi=base64_encode(gzdeflate(str_rot13(gzdeflate($text))));
        break;case 'hexencode' : $codi=bin2hex($text);
        break;case 'str_rot13' : $codi=str_rot13($text);
        break;case 'strlen' : $codi=strlen($text);
        break;case 'xxx' : $codi=strlen(bin2hex($text));
        break;case 'bbb' : $codi=htmlentities(utf8_decode($text));
        break;case 'aaa' : $codi=chr(bin2hex(substr($text)));
        break;case 'www' : $codi=chr($text);
        break;case 'sss' : $codi=htmlspecialchars($text);
        break;case 'eee' : $codi=addslashes($text);
        break;case 'gzinflatess' : $codi=base64_encode(gzcompress($text));
        break;case 'gzinflates' : $codi=base64_encode(gzdeflate($text));
        break;case 'str2' : $codi=base64_encode(str_rot13($text));
        break;case 'urlencode' : $codi=rawurlencode($text);
        break;case 'ur' : $codi=convert_uuencode($text);
        break;case 'url' : $codi=base64_encode(gzdeflate(convert_uuencode(str_rot13(gzdeflate(base64_encode($text))))));
        break;default:break;}}
        
        $submit = $_POST['crack'];
        if (isset($submit)){
        $op = $_POST["ope"];
        switch ($op) {case 'base64': $codi=base64_decode($text);
        break;case 'str' : $codi=str_rot13(gzinflate(str_rot13(base64_decode(($text)))));
        break;case 'gzinflate' : $codi=str_rot13(gzinflate(base64_decode($text)));
        break;case 'json' : $codi=utf8_dencode(json_dencode($text));
        break;case 'gzinflater' : $codi=gzinflate(str_rot13(base64_decode($text)));
        break;case 'gzinflatex' : $codi=gzinflate(str_rot13(gzinflate(base64_decode($text))));
        break;case 'gzinflatess' : $codi=gzuncompress(base64_decode($text));
        break;case 'gzinflates' : $codi=gzinflate(base64_decode($text));
        break;case 'str2' : $codi=str_rot13(base64_decode($text));
        break;case 'urlencode' : $codi=rawurldecode($text);
        break;case 'hexencode' : $codi=quoted_printable_decode($text);
        break;case 'ur' : $codi=convert_uudecode($text);
        break;case 'url' : $codi=base64_decode(gzinflate(str_rot13(convert_uudecode(gzinflate(base64_decode(($text)))))));
        break;default:break;}}
        $html = htmlentities(stripslashes($codi));
echo "<from><center>
<textarea id='MyOutput' class='form-control text-dark' rows='10' cols='90' readonly>".$html."</textarea></center></from>";
?><script>

    function myFunction() {
      var copyText = document.getElementById("MyOutput");
    
      copyText.select();
      copyText.setSelectionRange(0, 99999);
    
      document.execCommand("copy");
    
      alert("Copy The Text : " + copyText.value);
    }

</script>
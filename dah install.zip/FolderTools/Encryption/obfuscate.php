
                                          <center><br><form action="" method="POST">
				<textarea class="form-control text-danger" rows="9" cols="85" type="text" name="php" placeholder="Input Php Code Here"></textarea><br><br>
				<select class='form-control' name="option">
					<option>Weak Obfuscation</option>
					<option>Medium Level Obfuscation</option>
					<option>Strong Obfuscation</option>
					<option>High Level Obfuscation</option>
				</select><br><br><br>
				<input type="submit" class="btn btn-outline-info" name="submit" value="Submit" /><br>
				<?php
					if (isset($_POST['submit'])) {
					$phpcode = $_POST['php'];
						if (!empty($phpcode)) {
							$option = htmlspecialchars($_POST['option']);
							$website = "http://".$_SERVER['HTTP_HOST'];
							$file_location = $_SERVER['REQUEST_URI'];
							$all_in_one = $website.$file_location;
							$uuencode = base64_encode(convert_uuencode($phpcode));
							$obfuscate_low_level = strrev(base64_encode(gzdeflate(gzcompress($phpcode))));
							$obfuscate_medium_level = strrev(base64_encode(gzdeflate(gzdeflate(gzcompress($phpcode)))));
							$obfuscate_high_level = strrev(base64_encode(gzdeflate(gzdeflate(gzdeflate(gzcompress(gzcompress($phpcode)))))));
							$high_level = strrev(base64_encode(gzcompress(gzdeflate(gzcompress(gzdeflate(gzcompress(gzdeflate(gzcompress(gzdeflate(str_rot13($phpcode)))))))))));
							$high_level_1 = str_replace('a', '\x61', $high_level);
							$high_level_2 = str_replace('A', '\x41', $high_level_1);
							$high_level_3 = str_replace('b', '\x62', $high_level_2);
							$high_level_4 = str_replace('B', '\x42', $high_level_3);
							$high_level_5 = str_replace('c', '\x63', $high_level_4);
							$high_level_6 = str_replace('C', '\x43', $high_level_5);
							$high_level_7 = str_replace('=', '\x3d', $high_level_6);
							$high_level_8 = str_replace('+', '\x2b', $high_level_7);
							switch ($option) {	
								case 'Weak Obfuscation':
									echo '
<textarea rows="9" cols="85">
<?php
$Cyto = "Sy1LzNFQt1dLL7FW10uvKs1Lzs8tKEotLtZIr8rMS8tJLEnVSEosTjUziU9JT\x635PSdUoLikqSi3TUPHJrNAE\x41Ws\x41";
$Lix = "'.$obfuscate_low_level.'";
eval(htmlspecialchars_decode(gzinflate(base64_decode($Cyto))));
exit;
?></textarea><br><br>
';
								break;

								case 'Medium Level Obfuscation':
									echo '<textarea rows="9" cols="85">
<?php
$Cyto = "Sy1LzNFQt1dLL7FW10uvKs1Lzs8tKEotLtZIr8rMS8tJLElFYiUlFqe\x61m\x63Snp\x43\x62np6RqFJ\x63UF\x61WW\x61\x61j4ZFZogoE1\x41\x41\x3d\x3d";
$Lix = "'.$obfuscate_medium_level.'";
eval(htmlspecialchars_decode(gzinflate(base64_decode($Cyto))));
exit;
?></textarea><br><br>
';

								break;

								case 'Strong Obfuscation':
									echo '<textarea rows="9" cols="85">
<?php
$Cyto = "Sy1LzNFQKyzNL7G2V0svsYYw9dKrSvOS83MLilKLizXQOJl5\x61TmJJ\x61lYWUmJx\x61lmJvEpq\x63n5K\x61k\x61xSVFR\x61llGio\x2bmRWaUGAN\x41\x41\x3d\x3d";
$Lix = "'.$obfuscate_high_level.'";
eval(htmlspecialchars_decode(gzinflate(base64_decode($Cyto))));
exit;
?></textarea><br><br>
';
								break;

								case 'High Level Obfuscation':
									echo '<textarea rows="9" cols="85">
<?php
$Cyto = "Sy1LzNFQKyzNL7G2V0svsYYw9YpLiuKL8ksMjTXSqzLz0nISS1K\x42rNK85Pz\x63gqLU4mLq\x43\x43\x63lFqe\x61m\x63Snp\x43\x62np6Rq\x41O0sSi3TUPHJrNBE\x41tY\x41";
$Lix = "'.$high_level_8.'";
eval(htmlspecialchars_decode(gzinflate(base64_decode($Cyto))));
exit;
?></textarea><br><br>
';
								break;
							} 
						}
					}
				?>
			</form>
		</div>
       </center>
 </div>
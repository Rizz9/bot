<center>
	<form method="POST">
		<input type="text" class="form-control" name="hash" placeholder="Hash to Brute"><br>
		<textarea name="pass" class="form-control" placeholder="List Text (Pisahkan Perbaris)" rows="8"></textarea><br>
	    <input type="submit" class="btn btn-round btn-dim btn-outline-success" name="submit" value="submit">
	</form>
	<br>
<div class="alert alert-danger">Tools Melakukan BruteForcing Terhadap Password dengan Memakai List Text yang User Submit, Waktu yang diperlukan Tergantung Jumlah List</div>
<br>
			<?php
set_time_limit(30000000000000);
if(isset($_POST['submit'])){
$hash = $_POST['hash'];
$pass = explode("\r\n",$_POST['pass']);
$start_time = microtime(true);
  foreach ($pass as $value) {
    if (password_verify($value, $hash)) {
      $end_time = microtime(true);
      echo "<div class='alert alert-success'>Password is " . $value . "\n<br>";
      echo "\n".'Time to Crack ' . round($end_time-$start_time). " seconds</div>\n";
    } else{
        $Not = '<div class="alert alert-danger">Done, Password Found or Overload or Not Found</div>';
    }
  }
  echo $Not;
}
?>
</center>
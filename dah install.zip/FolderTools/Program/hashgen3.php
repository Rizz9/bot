<center>
<? $hashtypes = hash_algos(); ?>
<script>
<?php
foreach($hashtypes as $hashtype) { $A = str_replace(",","",$hashtype); $B = str_replace("/","",$A); $C = str_replace("-","",$B); ?> function <? echo $C."()"?> {
			document.getElementById("<? echo $C ?>").select();
			document.execCommand("copy");
			swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
		}
		<? } ?>
</script>
              <script>
		function Bcrypt() {
		    document.getElementById("Bcrypt").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
} function Blowfish() {
		    document.getElementById("Blowfish").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
} 
function Argon2I() {
		    document.getElementById("Argon2I").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
}
function Argon2ID() {
		    document.getElementById("Argon2ID").select();
			document.execCommand("copy");
  swal.fire({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    icon : 'success',
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
}
	</script>
	<form method="post">
		<input type="text" name="pass" class="form-control mb-3" value="<? echo $_POST['pass']; ?>" placeholder="Text">
		<center>
		<button type="submit" name="hash" class="btn btn-outline-danger">Hash Text/Password</button>
		</center>
	</form><br>
<?php 
if(isset($_POST["hash"])){
$pass = htmlspecialchars(addslashes($_POST["pass"]));
foreach($hashtypes as $hashtype) {
$hashed= hash("$hashtype" , $pass);
$A = str_replace(",","",$hashtype); $B = str_replace("/","",$A); $C = str_replace("-","",$B);
if(!empty($pass)){
?>
			<font class="text-warning" size="3"><?= $hashtype ?></font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="<?= $hashed ?>" onclick="<? echo $C."()" ?>" id="<? echo $C ?>"/><br>
<?  }} 
$Bcrypt = password_hash($pass,PASSWORD_DEFAULT);
$BcryptBlowfish = password_hash($pass,PASSWORD_BCRYPT);
$Argon2I = password_hash($pass,PASSWORD_ARGON2I);
$Argon2ID = password_hash($pass,PASSWORD_ARGON2ID);?>
<font class="text-warning" size="3">Bcrypt</font>
<input type="text" readonly="readonly" class="form-control bg-transparent" value="<?= $Bcrypt ?>" onclick="Bcrypt()" id="Bcrypt"/><br>
<font class="text-warning" size="3">Bcrypt Blowfish</font>
<input type="text" readonly="readonly" class="form-control bg-transparent" value="<?= $BcryptBlowfish ?>" onclick="Blowfish()" id="Blowfish"/><br>
<font class="text-warning" size="3">Argon2I</font>
<input type="text" readonly="readonly" class="form-control bg-transparent" value="<?= $Argon2I ?>" onclick="Argon2I()" id="Argon2I"/><br>
<font class="text-warning" size="3">Argon2ID</font>
<input type="text" readonly="readonly" class="form-control bg-transparent" value="<?= $Argon2ID ?>" onclick="Argon2ID()" id="Argon2ID"/><br>

<? } ?>
</center>
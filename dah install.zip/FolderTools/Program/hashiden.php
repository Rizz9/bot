<?php 
if (isset($_POST['gethash'])) {
	$hash = $_POST['hash'];
	if (strlen($hash) == 32) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MD5 Hash </div>";
	} elseif (strlen($hash) == 40) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : SHA-1 Hash/ /MySQL5 Hash </div>";
	} elseif (strlen($hash) == 13) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : DES(Unix) Hash </div>";
	} elseif (strlen($hash) == 16) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MySQL Hash / /DES(Oracle Hash) </div>";
	} elseif (strlen($hash) == 41) {
	$GetHashChar = substr($hash, 40);
	if ($GetHashChar == "*") {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MySQL5 Hash </div>";
	}
	} elseif (strlen($hash) == 64) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : SHA-256 Hash </div>";
	} elseif (strlen($hash) == 96) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : SHA-384 Hash </div>";
	} elseif (strlen($hash) == 128) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : SHA-512 Hash </div>";
	} elseif (strlen($hash) == 34) {
	if (strstr($hash, '$1$')) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MD5(Unix) Hash </div>";
	}
	} elseif (strlen($hash) == 37) {
	if (strstr($hash, '$apr1$')) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MD5(APR) Hash </div>";
	}
	} elseif (strlen($hash) == 34) {
	if (strstr($hash, '$H$')) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MD5(phpBB3) Hash </div>";
	}
	} elseif (strlen($hash) == 34) {
	if (strstr($hash, '$P$')) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MD5(Wordpress) Hash </div>";
	}
	} elseif (strlen($hash) == 39) {
	if (strstr($hash, '$5$')) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : SHA-256(Unix) Hash </div>";
	}
	} elseif (strlen($hash) == 39) {
	if (strstr($hash, '$6$')) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : SHA-512(Unix) Hash </div>";
	}
	} elseif (strlen($hash) == 24) {
	if (strstr($hash, '==')) {
	$hashresult = "<br><div class='alert alert-success'> Found Type : MD5(Base-64) Hash </div>";
	}
	} else {
	$hashresult = "<br><div class='alert alert-danger'> Hash type not found </div>";
	}
	} else {
	$hashresult = "<br><div class='alert alert-warning'> Masukin Hash nya dulu mas </div>";
	}
	?>
	
	
	<form action="" method="POST">
	    <label>Enter Hash :</label>
	    <input type="text" name="hash" size='60' class="form-control text-warning" /><br>
       <input type="submit" class="btn btn-outline-warning" name="gethash" value="Identify Hash" /><br>
<?php echo $hashresult; ?>
 </form>

          
      <script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js></script>

  <tr>
    <td>

        <center>
            <p class="text-danger">Note : Up File Images dan Tunggu Beberapa Detik Hingga Selesai Encoding</p>
            <div class="form-group">
                <label class="form-label" for="customMultipleFilesLabel">File Upload</label>
                    <div class="form-control-wrap">
                        <div class="custom-file">
                            <input class="custom-file-input" name=userfile id=userfile type="file">
                            <label class="custom-file-label" for="customMultipleFiles">Choose files</label>
                        </div>
                    </div>
            </div>
            <br><br>
            <div id=preview>
        </center>
        <br><br>
    </td>
  </tr>

<script type=text/javascript>function readFile(evt) { var f = evt.target.files[0]; if (f) { if (/(jpe?g|png|gif|bmp)$/i.test(f.type)) { if (f.size < 800000) { var r = new FileReader(); r.onload = function(e) { $('#filechoose').val(f.name); var base64Img = e.target.result; var html = '<img src="' + base64Img + '" height="280" width="260"/><br><br>'; html += '<font color="silver" size="5">Base64 String</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="1">' + base64Img + '</textarea><br><br><button class="btn btn-outline-warning" onclick="myFunction()">Copy Text</button><br><br>'; html += '<font color="silver" size="5">CSS Background IMG</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="2">' + '&lt;style type="text/css"&gt;\n' + 'div.image {\n' + 'width: 100px;\n' + 'height: 100px;\n' + 'background-image: url("' + base64Img + '");\n' + '}\n' + '&lt;/style&gt;\n' + '</textarea><br><br><button class="btn btn-outline-warning" onclick="myFunctionn()">Copy Text</button><br><br>'; html += '<font color="silver" size="5">XHTML IMG</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="3"> &lt;img src="' + base64Img + '"/&gt;</textarea><br><br><button class="btn btn-outline-warning" onclick="myFunctionnn()">Copy Text</button><br><br>'; html += '<font color="silver" size="5">XML IMG</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="4">' + '&lt;image&gt;\n' + '&lt;title&gt;An Image&lt;/title&gt;\n' + '&lt;link&gt;http://www.your.domain&lt;/link&gt;\n' + '&lt;url&gt;' + base64Img + '&lt;/url&gt;\n' + '&lt;/image&gt; </textarea><br><br><button class="btn btn-outline-warning" onclick="myFunctionnnn()">Copy Text</button><br><br>'; $('#preview').html(html); }; r.readAsDataURL(f); } else { alert("File Terlalu Besar :v"); } } else { alert("DISURUH UPLOAD FILE IMAGES BUKAN BACKDOOR"); } } else { alert("Gagal load file."); } } document.getElementById('userfile').addEventListener('change', readFile, false);</script>
<script> function myFunction() { var copyText = document.getElementById("1"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionn() { var copyText = document.getElementById("2"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnn() { var copyText = document.getElementById("3"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnnn() { var copyText = document.getElementById("4"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); }</script>
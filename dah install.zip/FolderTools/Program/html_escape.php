
          
          <?php
error_reporting(0);
if(isset($_POST["escapecode"])){
	if(empty($input = $_POST["input"])){
		echo "<script>Swal.fire({
					  	title: 'Error',
					  	text: 'Text Tidak Boleh Kosong',
					})</script>";
	}
function encode($input) 
{ 
    $temp = ''; 
    $length = strlen($input); 
    for($i = 0; $i < $length; $i++) 
        $temp .= '%' . bin2hex($input[$i]); 
    return $temp; 
} 
$str = encode($input); 
$enc = "<script language='javascript'>
document.write(escape('".$str."'));
</script>";
}

?>

<script>
		function copy() {
			document.getElementById("output").select();
			document.execCommand("copy");
			Swal.fire({
					  	title: 'Berhasil',
					  	text: 'Text Berhasil Disalin',
					})
		}
	
</script>

<form method="post">
<div class="row">
	<div class="col-md-6">
		<div class="tile">
			<textarea class="form-control" rows="8" name="input" id="input" placeholder="Text"></textarea>
		</div>
	</div>
	<div class="col-md-6">
		<div class="tile">
			<textarea class="form-control bg-transparent" rows="8" name="output" id="output" placeholder="Result" readonly="readonly"><?= str_replace("escape","unescape",$enc); ?></textarea>
		</div>
	</div>
</div>
<br>
<div class="tile">
	<div class="row">
		<div class="col">
			<button class="btn btn-danger btn-block" type="submit" name="escapecode">Escape Code</button>
		</div>
		<div class="col">
			<button type="button" class="btn btn-danger btn-block" onclick="copy()">Copy</button>
		</div>
	</div>
</div>
</form>

      <center>
				    		<table>
				    			<style>
				    				#result{
				    				resize:none;
				    				width:500px;
				    				height:500px;
				    			}
				    			h1{
				    				font-size: 40px;
				    			}
				    			iframe{
				    				background-color: white;
				    				color: black;
				    				resize: none;
				    				font-family: 'Teko',sans-serif;
				    				width: 500px;
				    				height: 500px;
				    			}
				    			textarea{
				    				width: 500px;
				    				height: 500px;
				    				color: black;
				    			}
				    		</style>
				    		<center>
				    			<br>
				    			<div class="card-body">
				    				<textarea rows="8" id="TextEditor" onkeyup="RunCode()" autofocus="autofocus">
				    				</textarea>
				    			</div>
				    			<br><hr color="white">
				    			<div class="container">
				    				<div class="row">
				    				</div>
				    				<br><lable>Output</lable><br><br><iframe id="result"></iframe>
				    			</div>
				    		</div>
				    		</center>
				    		</table>
				    	</center>
				    
	<script>
		function RunCode() {
			var CodeText = document.getElementById('TextEditor').value;
			document.getElementById('result').srcdoc = CodeText;
		}
	</script>

          
          <script>
		function salin() {
		    document.getElementById("output").select();
			document.execCommand("copy");
  swal({
    title: 'Berhasil Disalin!',
    width: 600,
    padding: "7em",
    customClass: "background-modal",
    background: '#fff url(<?php echo $selected_bg ?>) no-repeat 100% 100%',
  })
}
    function runCharCodeAt() {
        input = document.charCodeAt.input.value;
        output = "";
        for(i=0; i<input.length; ++i) {
            if (output != "") output += " ";
            output += input.charCodeAt(i);
        }
        document.charCodeAt.output.value = output;
    }
</script>
	
				<div class="tile-body">
					<form name="charCodeAt" method="post">
		<textarea name="input" class="form-control" placeholder="Text" rows="8"></textarea>
				</div>
			<br>
			<div class="row">
				<div class="col">
					<button type="button" onclick="runCharCodeAt()" class="btn btn-primary btn-block">Create</button>
		</div>
	<div class="col">
			<button type="button" onclick="salin()" class="btn btn-success btn-block"><i class="fa fa-clone"></i></button>
				</div>
			</div>
		<br>
			<textarea id="output" class="form-control bg-transparent" rows="8" placeholder="Charcode" readonly></textarea>
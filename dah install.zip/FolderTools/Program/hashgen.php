
  <center>
        <?php
            {
              $submit= $_POST['enter'];
                    if (isset($submit)) {
                        $pass = htmlspecialchars($_POST['password']);
                        $salt = '}#f4ga~g%7hjg4&j(7mk?/!bj30ab-wi=6^7-$^R9F|GK5J#E6WT;IO[JN';
                        $md2 = hash("md2" , $pass);
                        $md4 = hash("md4" , $pass);
                        $md5 = hash("md5" , $pass);
                        $sha1 = hash("sha1" , $pass);
                        $sha256 = hash("sha256" , $pass);
                        $sha512 = hash("sha512" , $pass);
                }
                echo '<form action="" method="post">';
                echo '<input class="form-control text-warning" placeholder="Text" type="text" name="password"/>';
                echo '<br><center><button class="btn btn-outline-danger" type="submit" name="enter" />Hash</button></center><br><br>';
                echo '<font color="silver" size="3">Text Asli</font><br><br><input class="form-control text-info" type="text" size="35" value='.$pass.'><br><br>';
                echo '<font color="silver" size="3">MD2</font><br><br><input class="form-control text-danger" id="1" onclick="myFunction()" type="text" size="35" value='.$md2.'><br><br>';
                echo '<font color="silver" size="3">MD4</font><br><br><input class="form-control text-danger" id="2" onclick="myFunctionn()" type="text" size="35" value='.$md4.'><br><br>';
                echo '<font color="silver" size="3">MD5</font><br><br><input class="form-control text-danger" id="3" onclick="myFunctionnn()" type="text" size="35" value='.$md5.'><br><br>';
                echo '<font color="silver" size="3">SHA1</font><br><br><input class="form-control text-danger" id="4" onclick="myFunctionnnn()" type="text" size="35" value='.$sha1.'><br><br>';
                echo '<font color="silver" size="3">SHA256</font><br><br><input class="form-control text-danger" id="5" onclick="myFunctionnnnn()" type="text" size="35" value='.$sha256.'><br><br>';
                echo '<font color="silver" size="3">SHA512</font><br><br><input class="form-control text-danger" id="6" onclick="myFunctionnnnnn()" type="text" size="35" value='.$sha512.'></td></tr><br><br>';
            }
        ?>
        <br><br>
   </center>

<script> function myFunction() { var copyText = document.getElementById("1"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionn() { var copyText = document.getElementById("2"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnn() { var copyText = document.getElementById("3"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnnn() { var copyText = document.getElementById("4"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnnnn() { var copyText = document.getElementById("5"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnnnnn() { var copyText = document.getElementById("6"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); }</script>


    
<center>
<form action="" method="post" enctype="multipart/form-data">
<input type="number" name="Nilai" class="form-control text-warning" placeholder="Masukkan Jumlah karakter">
<br>
<input type="submit" class="btn btn-outline-warning" value="Create Pass" />
<button class="btn btn-outline-warning" onclick="myFunction()">Copy Text</button>
<form>
<?php
$Nilai = htmlspecialchars($_POST['Nilai']);
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~`!@#$%^&*()_-=+{[]}|\?/.,<>;:"';
 
function generate_string($input, $strength = 16) {
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
 
    return $random_string;
}

$pattern = '/([^0-9]+)/';
$NilaiA = $Nilai;
$NilaiB = preg_replace($pattern,'',$NilaiA);
if ($NilaiB > 9999){
    echo '<br><br><textarea class="form-control text-danger" id="HelixUwU" readonly>OVERLOAD, oniichan ba-baka >\\\<</textarea>';
} else {
$Result = generate_string($permitted_chars, $NilaiB);
echo '<br><br><textarea class="form-control text-danger" id="HelixUwU" readonly>'.$Result.'</textarea>';
} ?>
</center>

<script>
function myFunction() {
var copyText = document.getElementById("HelixUwU");
copyText.select();
copyText.setSelectionRange(0, 99999);
document.execCommand("copy");
alert("Helix UwU Success Copy " + copyText.value);
}
</script>
<?php
	@set_time_limit(0);
	function curl_($mail){
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, "https://www.amazon.com/ap/register?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dgno_newcust?&email=".$mail); 
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36");
		curl_setopt($ch, CURLOPT_REFERER, "https://www.amazon.com/"); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 3);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		$result = curl_exec($ch); 
		return $result;
		curl_close($ch);
	}
?>
          <center><form method="POST" name="praga">
					<textarea class="form-control text-danger" cols="auto" rows="10" id="text" name="mail"><?php if(isset($_POST['mail'])){ echo $_POST['mail']; } ?></textarea>
					<br><br>
					<input type="submit" value="Check!!" name="sub" class="btn btn-outline-primary" />
				</form></center><br>
					<?php
		if(isset($_POST['sub'])){
			$email_list=$_POST['mail'];
			$line = explode("\r\n",$email_list);
			$line = array_unique($line);
			$j=0;$k=0;$o=0;
			for($i=0;$i<count($line);$i++){
				if (filter_var($line[$i], FILTER_VALIDATE_EMAIL)) {
				    $rez=curl_($line[$i]);
					echo "<font color='green'> valid ==> </font>".$line[$i]."...";
						
						if (strpos($rez,'You indicated you are a new customer' ) ){ 
						echo "<font color='green'> Ok . <br> </font>";
						$live[$j]=$line[$i];
						$j++;
					}elseif(strpos($rez,'Create account' ) ){
						echo "<font color='red'> Noo . <br> </font>";
						$die[$o]=$line[$i];
						$o++;
					}else{
						echo "<font color='red'> CanT Check !! . <br> </font>";
						$die[$o]=$line[$i];
						$o++;
					}
				}else{
				echo "<font color='red'> Invalid mail </font>=>".$line[$i]."<br>";
				$not[$k]=$line[$i];
				$k++;
				}
			flush(); ob_flush();
			
			
			}
		?>
		<table border="0" width="100%">
			<tr>
			<td align='center' style="color:green"> Valid Email (<?php echo @count($live);?>)</td>
			<td align='center' style="color:red"> Not Valid Emails (<?php echo @count($die);?>)</td>
			<td align='center' style="color:orange"> Invalid Emails (<?php echo @count($not);?>)</td>
			</tr>
		<?php
		if(isset($live)){ echo "<tr><td align='center' ><textarea class='form-control text-info' cols='auto' rows='10'>";for($i=0;$i<count($live);$i++){echo $live[$i]."\n"; } echo "</textarea></td>";}else{echo "<td align='center' ><textarea class='form-control text-danger' cols='auto' rows='10'></textarea>"; }
		if(isset($die)){ echo "<td align='center' ><textarea class='form-control text-danger' cols='auto' rows='10'>";for($i=0;$i<count($die);$i++){echo $die[$i]."\n"; } echo "</textarea></td>";}else{echo "<td align='center' ><textarea class='form-control text-danger' cols='auto' rows='10'></textarea>"; }
		if(isset($not)){ echo "<td align='center' ><textarea class='form-control text-danger' cols='auto' rows='10'>";for($i=0;$i<count($not);$i++){echo $not[$i]."\n"; } echo "</textarea>";}else{echo "<td align='center' ><textarea class='form-control text-danger' cols='auto' rows='10'></textarea></td><tr></table>";}
		}	
	?></table>
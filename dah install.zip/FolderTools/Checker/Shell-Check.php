
         
               <form  method="POST">
             <textarea name="url" cols="50" class="form-control text-light" rows="10" placeholder="https://www.helixsid.today/shell.php"></textarea><br>
             <center>
                 <input type="submit"  class="btn btn-primary" name="GO" value="Go">
             </center>
      </form>       
      <?php
if(isset($_POST['GO'])){
    echo '<label>live</label><textarea cols="50" rows="10" class="form-control">';
$sites = $_POST['url'];
$URL1 = str_replace('https://','',$sites);
$URL2 = str_replace('http://','',$URL1);
$URL = explode("\r\n",$URL2);
foreach($URL as $url){
      ?>
      <?php  if($url){ ?>
          <?php
            $time_start = microtime(TRUE);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $time_end = microtime(TRUE);
            $time_diff = ($time_end - $time_start);
            list($header, $body) = explode("\r\n\r\n", $response, 2);
         ?>
              <?php
if($httpcode == "200"){
                $live = $url;
}
              ?>
              <?
              }
              echo $live;
}
              } echo'</textarea>';  ?>
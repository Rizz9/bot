<html>
<head>
<title> GIIK4YOU !!</title>
<script type="text/javascript">
window.location = "/home";
</script>
<head>
<body> Sedang Mengalihkan Ke Halaman Utama.</body>
</html>
<?php
include'config.php';
header('Content-type: application/xml; charset=utf-8');
echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
    <?php
    $ALLL = "https://tools.giik.site";
        echo "<url>";
        echo "<loc>";
        $index = "".$ALLL."/home/?index";
        echo $index;
        echo"</loc>";
        echo "<priority>1.00</priority>";
        echo "</url>";
        echo "<url>";
        echo "<loc>";
        $index2 = "".$ALLL."/home2/?index";
        echo $index2;
        echo"</loc>";
        echo "<priority>1.00</priority>";
        echo "</url>";
        echo "<url>";
        echo "<loc>";
        $list = "".$ALLL."/home2/?List";
        echo $list;
        echo"</loc>";
        echo "<priority>1.00</priority>";
        echo "</url>";
        echo "<url>";
        echo "<loc>";
        $list = "".$ALLL."/home/?pages";
        echo $list;
        echo"</loc>";
        echo "<priority>1.00</priority>";
        echo "</url>";
        echo "<url>";
        echo "<loc>";
        $list = "".$ALLL."/home/blog/";
        echo $list;
        echo"</loc>";
        echo "<priority>1.00</priority>";
        echo "</url>";
        $resultMapBlog= mysqli_query($config, "SELECT * FROM Blog ORDER BY id");
                while ($rowMapBlog = mysqli_fetch_array($resultMapBlog)) {
        echo "<url>";
        echo "<loc>";
        $link1 = "".$ALLL."/home/blog/".$rowMapBlog['Blog_slug']."";
        echo $link1;
        echo"</loc>";
        echo "<priority>0.8</priority>";
        echo "</url>";
    }
    $resultMapPages= mysqli_query($config, "SELECT * FROM contents ORDER BY id");
                while ($rowMapPages = mysqli_fetch_array($resultMapPages)) {
        echo "<url>";
        echo "<loc>";
        $link1 = "".$ALLL."/home/?pages=".$rowMapPages['content_slug']."";
        echo $link1;
        echo"</loc>";
        echo "<priority>0.8</priority>";
        echo "</url>";
    }
    $resultMapF= mysqli_query($config, "SELECT * FROM tools2 ORDER BY id");
                while ($rowMapF = mysqli_fetch_array($resultMapF)) {
        echo "<url>";
        echo "<loc>";
        $link1 = "".$ALLL."/home/?tools=".$rowMapF['link']."";
        echo $link1;
        echo"</loc>";
        echo "<priority>0.8</priority>";
        echo "</url>";
    }
    $resultMap2 = mysqli_query($config, "SELECT * FROM tools2 ORDER BY id");
                while ($rowMap2 = mysqli_fetch_array($resultMap2)) {
        echo "<url>";
        echo "<loc>";
        $link1 = "".$ALLL."/home2/?tools=".$rowMap2['link']."";
        echo $link1;
        echo"</loc>";
        echo "<priority>0.8</priority>";
        echo "</url>";
    }
    ?>
</urlset>
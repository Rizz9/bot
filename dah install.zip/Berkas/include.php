          <!-- Network Tools -->
          <?php if($_GET['tools'] == 'ipgeo') { include'../FolderTools/Network/ipgeo.php'; 
          }
          elseif($_GET['tools'] == 'whois') { include'../FolderTools/Network/whois.php'; 
          }
          elseif($_GET['tools'] == 'revip') { include'../FolderTools/Network/revip.php'; 
          }
          elseif($_GET['tools'] == 'domain') { include'../FolderTools/Network/domain.php'; include'../sec.php';
          }
          elseif($_GET['tools'] == 'dns') { include'../FolderTools/Network/dns.php'; 
          }
          elseif($_GET['tools'] == 'revdns') { include'../FolderTools/Network/revdns.php'; 
          }
          elseif($_GET['tools'] == 'protocol') { include'../FolderTools/Network/protocol.php'; 
          }
          elseif($_GET['tools'] == 'zonh') { include'../FolderTools/Network/zonh.php'; 
          }
          elseif($_GET['tools'] == 'Sbdf1') { include'../FolderTools/Network/subdofind.php'; 
          }
          elseif($_GET['tools'] == 'Sbdf2') { include'../FolderTools/Network/subdofind2.php'; 
          }
          elseif($_GET['tools'] == 'Domain-to-IP') { include'../FolderTools/Network/DomaintoIP.php'; 
          }
          elseif($_GET['tools'] == 'Dir-Search') { include'../FolderTools/Network/Dir-Search.php'; 
          }
          elseif($_GET['tools'] == 'CMS-Scan') { include'../FolderTools/Network/cms-scan.php'; 
          }
          elseif($_GET['tools'] == 'checkip') { include'../FolderTools/Network/checkip.php'; include'../sec.php'; 
          }
          elseif($_GET['tools'] == 'pagecheck') { include'../FolderTools/Network/pagecheck.php'; 
          }
          elseif($_GET['tools'] == 'IPs') { include'../FolderTools/Network/GeoIPMaker.php'; 
          }
          ?>
          <!-- Network Tools End -->
          
          <!-- Program Tools -->
          <?php if($_GET['tools'] == 'livecoding') { include'../FolderTools/Program/livecoding.php'; 
          }
          elseif($_GET['tools'] == 'img') { include'../FolderTools/Program/img.php'; 
          }
          elseif($_GET['tools'] == 'hashgen') { include'../FolderTools/Program/hashgen.php'; 
          }
          elseif($_GET['tools'] == 'hashgen2') { include'../FolderTools/Program/hashgen2.php'; 
          }
          elseif($_GET['tools'] == 'hashgen3') { include'../FolderTools/Program/hashgen3.php'; 
          }
          elseif($_GET['tools'] == 'htmlen1') { include'../FolderTools/Program/html_en1.php'; 
          }
          elseif($_GET['tools'] == 'hashiden') { include'../FolderTools/Program/hashiden.php'; 
          }
          elseif($_GET['tools'] == 'Random-Pass') { include'../FolderTools/Program/Random-Password-Generator.php'; 
          }
          elseif($_GET['tools'] == 'Charcode') { include'../FolderTools/Program/Charcode.php'; 
          }
          elseif($_GET['tools'] == 'HTML-Escape') { include'../FolderTools/Program/html_escape.php'; 
          }
          elseif($_GET['tools'] == 'Remover') { include'../FolderTools/Program/Remover.php'; 
          }
          elseif($_GET['tools'] == 'Text-to-Array') { include'../FolderTools/Program/texttoarray.php'; 
          }
          elseif($_GET['tools'] == 'BrainFuck') { include'../FolderTools/Program/brainfuck.php'; 
          }
          
          
          ?>
          <!-- Program Tools End -->
          
          <!-- Pentesting Tools -->
          <?php if($_GET['tools'] == 'csrf') { include'../FolderTools/Pentesting/csrf.php'; 
          }
          elseif($_GET['tools'] == 'jso') { include'../FolderTools/Pentesting/jso.php';
          }
          elseif($_GET['tools'] == 'minihackbar') { include'../FolderTools/Pentesting/minihackbar.php'; 
          }
          elseif($_GET['tools'] == 'cbt') { include'../FolderTools/Pentesting/cbt.php'; 
          }
          elseif($_GET['tools'] == 'ojs') { include'../FolderTools/Pentesting/ojs.php'; 
          }
          elseif($_GET['tools'] == 'xamp') { include'../FolderTools/Pentesting/xamppauto.php'; 
          }
          elseif($_GET['tools'] == 'adfind') { include'../FolderTools/Pentesting/adfin.php';
          }
          elseif($_GET['tools'] == 'cj') { include'../FolderTools/Pentesting/click.php'; 
          }
          elseif($_GET['tools'] == 'CMS-Sekolahku') { include'../FolderTools/Pentesting/CMS_SekolahkuSqli.php'; 
          }
          elseif($_GET['tools'] == 'SchoolHost-Auto-Xploit') { include'../FolderTools/Pentesting/SchoolHost-Auto-Xploit.php'; 
          }
          elseif($_GET['tools'] == 'Balitbang-SQLI') { include'../FolderTools/Pentesting/Balitbang-SQLI.php'; 
          }
          elseif($_GET['tools'] == 'Timthumb-Auto-Xploit') { include'../FolderTools/Pentesting/timthumb.php'; 
          }
          elseif($_GET['tools'] == 'Drupal-Auto-Xploit') { include'../FolderTools/Pentesting/drupal-xploit.php'; 
          }
          elseif($_GET['tools'] == 'CMS-IAD') { include'../FolderTools/Pentesting/CMS-IAD.php'; 
          }
          elseif($_GET['tools'] == 'Shell-Finder') { include'../FolderTools/Pentesting/Shell-Finder.php'; 
          }
          elseif($_GET['tools'] == 'AKP') { include'../FolderTools/Pentesting/AKP.php'; 
          }
          elseif($_GET['tools'] == 'E-Sakip') { include'../FolderTools/Pentesting/E-Sakip.php'; 
          }
          elseif($_GET['tools'] == 'PHP-Unit') { include'../FolderTools/Pentesting/PHP-Unit.php'; 
          }
          elseif($_GET['tools'] == 'OR-Scan') { include'../FolderTools/Pentesting/URL-Red.php'; 
          }
          ?>
          <!-- Pentesting Tools End -->
          
          <!-- Checker Tools -->
          <?php if($_GET['tools'] == 'cc') { echo"Maintenance"; //include'../FolderTools/Checker/cc.php'; 
          }
          elseif($_GET['tools'] == 'paypal') { echo"Maintenance"; //include'../FolderTools/Checker/paypal.php'; 
          }
          elseif($_GET['tools'] == 'amazon') { include'../FolderTools/Checker/amazon.php'; 
          }
          elseif($_GET['tools'] == 'CekOng') { include'../FolderTools/Checker/Cek-Ongkr.php'; 
          }
          elseif($_GET['tools'] == 'Track') { include'../FolderTools/Checker/Track.php'; 
          }
          elseif($_GET['tools'] == 'Typo') { include'../FolderTools/Checker/Typo.php'; 
          }
          elseif($_GET['tools'] == 'Shell-Check') { include'../FolderTools/Checker/Shell-Check.php'; 
          }
          ?>
          <!-- Checker Tools End -->
          
          <!-- Encryption Tools -->
          <?php if($_GET['tools'] == 'endec') { include'../FolderTools/Encryption/endec.php'; 
          }
          elseif($_GET['tools'] == 'endec2') { include'../FolderTools/Encryption/endec2.php'; 
          }
          elseif($_GET['tools'] == 'obfuscate') { include'../FolderTools/Encryption/obfuscate.php'; 
          }
          elseif($_GET['tools'] == 'SHA') { include'../FolderTools/Encryption/SHA.php'; 
          }
          elseif($_GET['tools'] == 'base32d') { include'../FolderTools/Encryption/base32d.php'; 
          }
          elseif($_GET['tools'] == 'base32e') { include'../FolderTools/Encryption/base32e.php'; 
          }
          elseif($_GET['tools'] == 'morse') { include'../FolderTools/Encryption/morse.php'; 
          }
          elseif($_GET['tools'] == 'ROT13') { include'../FolderTools/Encryption/ROT13.php'; 
          }
          elseif($_GET['tools'] == 'cipher') { include'../FolderTools/Encryption/cipher.php'; 
          }
          elseif($_GET['tools'] == 'bcrypt') { include'../FolderTools/Encryption/bcrypt.php'; 
          }
          elseif($_GET['tools'] == 'bcrypt-brute1') { include'../FolderTools/Encryption/bcrypt-brute1.php'; 
          }
          elseif($_GET['tools'] == 'bcrypt-brute2') { include'../FolderTools/Encryption/bcrypt-brute2.php'; 
          }
          elseif($_GET['tools'] == 'Argon2I') { include'../FolderTools/Encryption/argon2i.php'; 
          }
          ?>
          <!-- Encryption Tools End -->
          
          <!-- Web Tools -->
          <?php if($_GET['tools'] == 'shorten') { include'../FolderTools/Web/shorten.php'; 
          }
          elseif($_GET['tools'] == 'shorten2') { include'../FolderTools/Web/shorten2.php'; 
          }
          elseif($_GET['tools'] == 'meta-tag-gen') { include'../FolderTools/Web/meta-tag-gen.php'; 
          }
          elseif($_GET['tools'] == 'Link-Scraper') { include'../FolderTools/Web/Link-Scraper.php'; 
          }
          elseif($_GET['tools'] == 'URL-List-Cleaner') { include'../FolderTools/Web/URL-List-Cleaner.php'; 
          }
          elseif($_GET['tools'] == 'Zone-D') { include'../FolderTools/Web/Zone-D.php'; 
          }
          elseif($_GET['tools'] == 'Zone-Xsec') { include'../FolderTools/Web/Zone-XSec.php'; 
          }
          elseif($_GET['tools'] == 'Mass-Add-File-Name') { include'../FolderTools/Web/MassAddFileName.php'; 
          }
          elseif($_GET['tools'] == 'Extract-Mail') { include'../FolderTools/Web/email.php'; 
          }
          elseif($_GET['tools'] == 'Grab-Domain-By-Date') { include'../FolderTools/Web/grabbydate.php'; 
          }
          elseif($_GET['tools'] == 'HaxorID') { include'../FolderTools/Web/haxorid.php'; 
          }
          ?>
          <!-- Web Tools End -->
          
          <!-- Mathematics Tools -->
          <?php 
          if($_GET['tools'] == 'persegi') { include'../FolderTools/Mathematics/persegi.php'; 
          }
          ?>
          <!-- Mathematics Tools End -->
          
          <!-- Other Tools -->
          <?php if($_GET['tools'] == 'bwatranslator') { include'../FolderTools/Other/bwatranslator.php'; 
          }
          elseif($_GET['tools'] == 'Downloader-Video') { include'../FolderTools/Other/Down.php'; 
          }
          elseif($_GET['tools'] == 'Gdrive') { include'../FolderTools/Other/gdrive.php'; 
          }
          elseif($_GET['tools'] == '1337') { include'../FolderTools/Other/1337.php'; 
          }
          elseif($_GET['tools'] == 'qr1') { include'../FolderTools/Other/qr1.php'; 
          }
          elseif($_GET['tools'] == 'qr2') { include'../FolderTools/Other/qr2.php'; 
          }
          elseif($_GET['tools'] == 'shalat') { include'../FolderTools/Other/Shalat.php';
          }
          elseif($_GET['tools'] == 'github-downloader') { include'../FolderTools/Other/Github.php';
          }
          elseif($_GET['tools'] == 'img-resizer') { include'../FolderTools/Other/img-resizer.php';
          }
          
          ?>
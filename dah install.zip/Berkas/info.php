<?php
// Mendapatkan IP pengunjung menggunakan getenv()
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'IP tidak dikenali';
    return $ipaddress;
}
  
  
// Mendapatkan IP pengunjung menggunakan $_SERVER
function get_client_ip_2() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'IP tidak dikenali';
    return $ipaddress;
}
  
  
// Mendapatkan jenis web browser pengunjung
function get_client_browser() {
    $browser = '';
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'Netscape'))
        $browser = 'Netscape';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox'))
        $browser = 'Firefox';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome'))
        $browser = 'Chrome';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera'))
        $browser = 'Opera';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE'))
        $browser = 'Internet Explorer';
    else
        $browser = 'Other';
    return $browser;
} 
function up_down() {
    $up_down = '';
    $updown = round(($finish - $mulai) * 1000, 2);
    if ($updown > 1000) 
    $up_down = 'Very Slow'; 
     elseif ($updown > 100)  
    $up_down = 'Slow'; 
     else
    $up_down = 'Fast'; 
    return $up_down;
}
?>                                            <div class="nk-block-head-xs">
                                                <div class="nk-block-between g-2">
                                                    <div class="nk-block-head-content">
                                                        <h6 class="nk-block-title title text-success">General Information</h6>
                                                    </div>
                                                    <div class="nk-block-head-content">
                                                        <a href="#" class="link link-primary toggle-opt active" data-target="user-info">
                                                            <div class="inactive-text">Show</div>
                                                            <div class="active-text">Hide</div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
<div class="toggle-expand-content expanded" data-content="user-info">
    <div class="card" data-content="User-Info">
        <div class="card-inner">
            <ul class="nav nav-tabs">    

                                                
                        <li class="nav-item">       
                            <a class="nav-link active" data-toggle="tab" href="#tabItem5">
                                <em class="icon ni ni-info-fill"></em>
                                <span>About</span>
                            </a>    
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#tabItem6">
                                <em class="icon ni ni-user"></em>
                                <span>Your Information</span>
                            </a>    
                        </li>  
                                                <li class="nav-item">        
                            <a class="nav-link" data-toggle="tab" href="#tabItem7">
                                <em class="icon ni ni-user-check"></em>
                                <span>Visitor</span>
                            </a>    
                        </li>
                        <li class="nav-item">        
                            <a class="nav-link" data-toggle="tab" href="#tabItem8">
                                <em class="icon ni ni-share-alt"></em>
                                <span>Privacy Policy</span>
                            </a>    
                        </li>
                        <li class="nav-item">        
                            <a class="nav-link" data-toggle="tab" href="#tabItem9">
                                <em class="icon ni ni-share-alt"></em>
                                <span>Terms & Conditions</span>
                            </a>    
                        </li>
            </ul>
            <div class="tab-content">                  
                                        
                    <div class="tab-pane active" id="tabItem5">        
                                <p><? echo $general_about['general_value'] ?>
</p>
<i>- Copyright © <?php echo date(Y) ?> Giik4You</i>
                    </div>    
                    
                                        <div class="tab-pane" id="tabItem6">        
                                                          <p>
                              <strong> This is Your Information</strong><br><?php
      echo "<b>IP : ". get_client_ip_2() ."<br>";
   echo "Browser : ".get_client_browser()."<br>";
   echo "Operation System : ".$_SERVER['HTTP_USER_AGENT']."<br>";
   echo "Load Time : " .$finish = microtime(true); print''. round(($finish - $mulai) * 2) ."<small>-ms</small> ".up_down()."<br>";
   echo "Domain : ".$_SERVER['SERVER_NAME']."<br>";
   echo "Path  : ".$_SERVER['REQUEST_URI']."<br>";
   echo "</b><br>";
?>
                          </p>   
                    </div>
                                        <div class="tab-pane" id="tabItem7">        
                                <p><?php echo 'Pageviews : ' .file_get_contents($filename)."<br>"; ?>
                                <?php require("../hit.php"); 
 echo "Unique Visitor : $info"; ?></p> 
                    </div>  
                    
                                        
                    <div class="tab-pane" id="tabItem8">        
                                <p>
                                    <? echo $general_terms['general_value'] ?>
</p>    
                    </div>
                                        <div class="tab-pane" id="tabItem9">        
                                <p>
                                    <? echo $general_terms['general_value'] ?>
</p>    
                    </div>                    
            </div

                                        
        </div>
    </div>
</div>
  </div> <br>
                                        <div class="nk-block-head-xs">
                                                <div class="nk-block-between g-2">
                                                    <div class="nk-block-head-content">
                                                        <h6 class="nk-block-title title text-success">Tools Views</h6>
                                                    </div>
                                                    <div class="nk-block-head-content">
                                                        <a href="#" class="link link-primary toggle-opt active" data-target="views">
                                                            <div class="inactive-text">Show</div>
                                                            <div class="active-text">Hide</div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                    <div class="toggle-expand-content expanded" data-content="views">
                                        <div class="col-md-6 col-xxl-3" data-content="views">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner mb-n2">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Top Tools View by Users</h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="nk-tb-list is-compact">
                                                    <div class="nk-tb-item nk-tb-head">
                                                        <div class="nk-tb-col"><span>Page</span></div>
                                                        <div class="nk-tb-col text-right"><span>Views</span></div>
                                                    </div><!-- .nk-tb-head -->
                                                    <?php $ResultView = mysqli_query($config,"SELECT * FROM PageView ORDER BY view DESC LIMIT 10");
                                                    while ($rowResultView = mysqli_fetch_array($ResultView)) {
                                                    ?>
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <span class="tb-sub"><span>/?tools=<?= $rowResultView['link'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $rowResultView['view']?></span></span>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <? } ?>
                                                </div><!-- .nk-tb-list -->
                                            </div><!-- .card -->
                                        </div>
                                    </div><br><!-- .col -->
                                    <div class="col-xxl-3 col-md-6">
                                            <div class="card h-100">
                                                <div class="card-inner">
                                                    <div class="card-title-group mb-2">
                                                        <div class="card-title">
                                                            <h6 class="title">Store Statistics</h6>
                                                        </div>
                                                    </div>
                                                    <ul class="nk-store-statistics">
                                                        <li class="item">
                                                            <div class="info">
                                                                <div class="title">Orders</div>
                                                                <div class="count">1,795</div>
                                                            </div>
                                                            <em class="icon bg-primary-dim ni ni-bag"></em>
                                                        </li>
                                                        <li class="item">
                                                            <div class="info">
                                                                <div class="title">Customers</div>
                                                                <div class="count">2,327</div>
                                                            </div>
                                                            <em class="icon bg-info-dim ni ni-users"></em>
                                                        </li>
                                                        <li class="item">
                                                            <div class="info">
                                                                <div class="title">Products</div>
                                                                <div class="count">674</div>
                                                            </div>
                                                            <em class="icon bg-pink-dim ni ni-box"></em>
                                                        </li>
                                                        <li class="item">
                                                            <div class="info">
                                                                <div class="title">Categories</div>
                                                                <div class="count">68</div>
                                                            </div>
                                                            <em class="icon bg-purple-dim ni ni-server"></em>
                                                        </li>
                                                    </ul>
                                                </div><!-- .card-inner -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->
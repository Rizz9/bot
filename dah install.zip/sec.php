<?php
error_reporting(0);
@clearstatcache();
@ini_set('error_log',NULL);
@ini_set('log_errors',0);
@ini_set('max_execution_time',0);
@ini_set('output_buffering',0);
@ini_set('display_errors', 0);
date_default_timezone_set('Asia/Jakarta');

$security_secret_file="hwkr.txt";
$alert="
<img src='https://i.ibb.co/8rXd3Rf/image-png.png' height='350px' width='350px'>
<center> 
    <p><font class='text-warning' size='5'>Sorry your ip has been block, Because You Trying to Hack This Site</font></p> 
  
<font class='text-danger' size='5'>&copy; 2021 4DSecurity</font></center>";
//--------------------------------------------//

function security_logger($ip) {
    $x=fopen("threat_log", "a");
    fwrite($x, $ip." ( ".$_SERVER['HTTP_USER_AGENT']." ".date("r")." ) "." => ".$_SERVER['REQUEST_URI']."\n");
    fclose($x);
}
function security_add_ip($ip, $time) {
    global $security_secret_file;
    $f=fopen($security_secret_file, "a");
    fwrite($f, $ip."^^^".$time."\n");
    fclose($f);
    security_logger($ip);
}

function security_del_ip($ip, $time) {
    global $security_secret_file;
    $file=file_get_contents($security_secret_file);
    $f=fopen($security_secret_file, "w");
    fwrite($f, str_replace($ip."^^^".$time."\n", "", $file));
    fclose($f);
}

$malicious="/alert\(|alert \(|<|>|\"|\||\'|information_schema|\/var|\/etc|\/home|file_get_contents|wget|script|%27|%0A|%0D|%22|%28|%3C|%3E|union|wget|cmd|proc|order|javascript|shell_exec|table_schema|user\(\)|user \(\)/";
$security_user_agent="/Mozilla|Chrome|Google|WhatsApp|Facebook|Telegram/";

if(!empty($_GET)) {
    foreach($_GET as $security_get_request) {
        if(preg_match("$malicious", $security_get_request)) {
            echo $alert;
            if(!preg_match($_SERVER['REMOTE_ADDR'], file_get_contents($security_secret_file))) {
                security_add_ip($_SERVER['REMOTE_ADDR'], time());
            }
            exit;
        }
    }
}

if(!empty($_POST)) {
    foreach($_POST as $security_post_request) {
        if(preg_match("$malicious", $security_post_request)) {
            echo $alert;
            if(!preg_match($_SERVER['REMOTE_ADDR'], file_get_contents($security_secret_file))) {
                security_add_ip($_SERVER['REMOTE_ADDR'], time());
            }
            exit;
        }
    }
}

if(!empty($_FILES)) {
    foreach($_FILES as $security_files_request) {
        if(preg_match("$malicious", $security_files_request)) {
            echo $alert;
            if(!preg_match($_SERVER['REMOTE_ADDR'], file_get_contents($security_secret_file))) {
                security_add_ip($_SERVER['REMOTE_ADDR'], time());
            }
            exit;
        }
    }
}

if(preg_match("/".$_SERVER['REMOTE_ADDR']."/", file_get_contents($security_secret_file))) {
    $security_file=explode("\n", file_get_contents($security_secret_file));
    foreach($security_file as $security_ip_line) {

        if(empty($security_ip_line)) {
            continue;
        }

        $security_ip_scan=explode('^^^', $security_ip_line);
        //IP Akan Terblokir Selama 24 Jam (Hitungan Dalam Second)
        if(time() > $security_ip_scan[1]+60*60*24 ) {
            if($security_ip_scan[0] == $_SERVER['REMOTE_ADDR']) {
                security_del_ip($security_ip_scan[0], $security_ip_scan[1]);
            } else {
                continue;
            }
        } else {
            echo $alert;
            exit;
        }
    }
}

if(!preg_match($security_user_agent, $_SERVER['HTTP_USER_AGENT'])) {
    security_add_ip($_SERVER['REMOTE_ADDR'], time());
    echo $alert;
    exit;
}
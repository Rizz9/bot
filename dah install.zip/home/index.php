<?php
if(isset($_GET['index'])){
        include'./Main.php';
        }
elseif (isset($_GET['pages'])){
    include'../general.php';
    include'../sec.php';
    include'helixdata/head.php';
    include'helixdata/sidebar.php';
    include'helixdata/bread.php';
    include'./Berkas/pages.php';
    include'./helixdata/footer.php';
} elseif (isset($_GET['tools'])){
    include'../general.php';
    include'helixdata/head.php';
    include'helixdata/sidebar.php';
    include'helixdata/bread.php';
    include'Berkas/tools.php';
    include'helixdata/footer.php';
} elseif (isset($_GET['blog'])){
    include'../general.php';
    include'../sec.php';
    include'helixdata/head.php';
    include'helixdata/sidebar.php';
    include'helixdata/bread.php';
    include'Berkas/blog.php';
    include'helixdata/footer.php';
} elseif (isset($_GET['API'])) {
    include'../general.php';
    include'../sec.php';
    include'helixdata/head.php';
    include'helixdata/sidebar.php';
    include'helixdata/bread.php';
    include'Berkas/api.php';
    include'helixdata/footer.php';
} elseif (isset($_GET['List'])) {
    include'../general.php';
    include'../sec.php';
    include'helixdata/head.php';
    include'helixdata/sidebar.php';
    include'helixdata/bread.php';
    include'Berkas/list.php';
    include'helixdata/footer.php';
} else {
    include'./Main.php';
}
<div class="nk-block nk-block-lg">
    <div class="toggle-expand-content expanded" data-content="All-files">
        <div class="nk-files nk-files-view-group">  
            <div class="card card-preview">
                <div class="card-inner">
                    <table class="datatable-init table">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Kategori</th>
                                <th>Link</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $resultCeker = mysqli_query($config, "SELECT * FROM tools2 ORDER BY id");
                                    while ($rowReportCek = mysqli_fetch_array($resultCeker)) {?>         
                            <tr>
                                <td><?= $rowReportCek['nametools']; ?></td>
                                <td><?= $rowReportCek['kategori']; ?></td>
                                <td><a href="?tools=<?= $rowReportCek['link']; ?>">Click</a></td>
                            </tr><?php } ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Nama</th>
                                <th>Kategori</th>
                                <th>Link</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
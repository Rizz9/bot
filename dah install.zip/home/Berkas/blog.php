                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
<?php
$content_slug = $_GET['blog'];
if($content_slug == NULL){
    ?>
    <div class="nk-block-head-xs">
                                                <div class="nk-block-between g-2">
                                                    <div class="nk-block-head-content">
                                                        <h6 class="nk-block-title title text-success">All Post</h6>
                                                    </div>
                                                    <div class="nk-block-head-content">
                                                        <a href="#" class="link link-primary toggle-opt active" data-target="Blog">
                                                            <div class="inactive-text">Show</div>
                                                            <div class="active-text">Hide</div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
<div class="toggle-expand-content expanded" data-content="Blog">
    
    <?$resultData = mysqli_query($config, "SELECT * FROM Blog ORDER BY ID");
                while ($rowData = mysqli_fetch_array($resultData)) {
?>
<div class="col-lg-4">
                                                        <div class="card card-bordered bg-teal-dim">
                                                            <div class="card-header border-bottom"><?= $rowData['Blog_title']; ?></div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title"><?= $rowData['Blog_title']; ?></h5>
                                                                <p class="card-text"><?= $rowData['Blog_description']; ?></p>
                                                                <a href="./blog/<?= $rowData['Blog_slug']; ?>" class="btn btn-outline-success">See Post</a>
                                                            </div>
                                                        </div>
                                                    </div><br><? } ?>
                                                    </div>
    <?
} else {
    $content = mysqli_fetch_array(mysqli_query($config,"SELECT * FROM Blog WHERE Blog_slug='$content_slug'"));
if(isset($_GET['blog'])) {
?>
                                   <div class="content-page wide-md m-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-xs mx-auto">
                                        <div class="nk-block-head-content text-center">
                                            <h2 class="nk-block-title fw-normal"><? echo $content['Blog_title'] ?></h2>
                                            <div class="nk-block-des">
                                                <p class="lead"><? echo $content['Blog_description'] ?></p>
                                                <p class="text-soft ff-italic"><? echo "Posted on ".$content['Blog_date'].""; ?></p>
                                            </div>
                                        </div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block">
                                        <div class="card card-bordered">
                                            <div class="card-inner card-inner-xl">
                                                <article class="entry">
                                                    <? echo $content['Blog_text'] ?>
                                                </article>
                                            </div>
                                        </div>
                                    </div><!-- .nk-block -->
                                </div><!-- .content-page --> 
<? }} ?>


</div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
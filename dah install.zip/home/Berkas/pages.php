                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
<?php
$content_slug = $_GET['pages'];
if($content_slug == NULL){
?>
<div class="nk-block-head-xs">
                                                <div class="nk-block-between g-2">
                                                    <div class="nk-block-head-content">
                                                        <h6 class="nk-block-title title text-success">All Pages</h6>
                                                    </div>
                                                    <div class="nk-block-head-content">
                                                        <a href="#" class="link link-primary toggle-opt active" data-target="Pages">
                                                            <div class="inactive-text">Show</div>
                                                            <div class="active-text">Hide</div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
<div class="toggle-expand-content expanded" data-content="Pages">
    
    <?$resultData = mysqli_query($config, "SELECT * FROM contents ORDER BY ID");
                while ($rowData = mysqli_fetch_array($resultData)) {
?>
<div class="col-lg-4">
                                                        <div class="card card-bordered bg-teal-dim">
                                                            <div class="card-header border-bottom"><?= $rowData['content_title']; ?></div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title"><?= $rowData['content_title']; ?></h5>
                                                                <p class="card-text"><?= $rowData['content_description']; ?></p>
                                                                <a href="./?pages=<?= $rowData['content_slug']; ?>" class="btn btn-outline-success">See Pages</a>
                                                            </div>
                                                        </div>
                                                    </div><br><? } ?>
                                                    </div>
<?
} else {
    $content = mysqli_fetch_array(mysqli_query($config,"SELECT * FROM contents WHERE content_slug='$content_slug'"));
if(isset($_GET['pages'])) {
?>
                                   <div class="content-page wide-md m-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-xs mx-auto">
                                        <div class="nk-block-head-content text-center">
                                            <h2 class="nk-block-title fw-normal"><? echo $content['content_title'] ?></h2>
                                            <div class="nk-block-des">
                                                <p class="lead"><? echo $content['content_description'] ?></p>
                                                <p class="text-soft ff-italic"><? echo "Posted on " .$content['content_opt']. "" ?></p>
                                            </div>
                                        </div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block">
                                        <div class="card card-bordered">
                                            <div class="card-inner card-inner-xl">
                                                <article class="entry">
                                                    <? echo $content['content_text'] ?>
                                                </article>
                                            </div>
                                        </div>
                                    </div><!-- .nk-block -->
                                </div><!-- .content-page --> 
<? }} ?>


</div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
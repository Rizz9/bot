                <!-- API -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                                
                                <div class="nk-content-body">
                                
                                            <div class="nk-block-head-xs">
                                                <div class="nk-block-between g-2">
                                                    <div class="nk-block-head-content">
                                                        <h6 class="nk-block-title title text-success">API</h6>
                                                    </div>
                                                    <div class="nk-block-head-content">
                                                        <a href="#" class="link link-primary toggle-opt active" data-target="API">
                                                            <div class="inactive-text">Show</div>
                                                            <div class="active-text">Hide</div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        <div class="toggle-expand-content expanded" data-content="API">

                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Zone-XSec Grabber</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Zone-XSec Grabber</h5>
                                                                <p class="card-text">Grab Site List From zone-xsec.com</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/xsec.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Zone-D Grabber</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Zone-D Grabber</h5>
                                                                <p class="card-text">Grab Site List From zone-d.org</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/z-d.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Reverse IP</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Reverse IP</h5>
                                                                <p class="card-text">Unlimited Reverse IP (Priv8 API)</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/revip.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Hax.or.id Grabber</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Hax.or.id Grabber</h5>
                                                                <p class="card-text">Grab Site List From hax.or.id</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/haxorid.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Grab Domain by Register Date</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Grab Domain by Register Date</h5>
                                                                <p class="card-text">Grab All Domain by Register Date</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/grabbydate.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">IP Generator</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">IP Generator</h5>
                                                                <p class="card-text">Make IP</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/IP-Maker.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Brainfuck Generator</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Brainfuck Generator</h5>
                                                                <p class="card-text">Generate Brainfuck Code From Text</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/brainfuck.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Email Extractor</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Email Extractor</h5>
                                                                <p class="card-text">Extract All Emails From Web Pages</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/email.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">SafeLinku URL Shortener</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">SafeLinku URL Shortener</h5>
                                                                <p class="card-text">This API Will Make Short URL for Safelinku That Covered by Cutt.ly Link</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/shorten-link.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">CMS Scanner</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">CMS Scanner</h5>
                                                                <p class="card-text">This API Will Detect the CMS used by a Website from the Given URL</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/cms-scan.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Hash Generator</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Hash Generator</h5>
                                                                <p class="card-text">Make Text to Hash Encryption, Support for (<?php echo implode(", ",hash_algos())?>)</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/hashgen.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Website Title Checker</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Website Title Checker</h5>
                                                                <p class="card-text">Check Title Value of Website</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/title.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Images Link Grabber</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Images Link Grabber</h5>
                                                                <p class="card-text">Grab All Link Image on Web Pages</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/images.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    <div class="col-lg-4">
                                                        <div class="card card-bordered bg-indigo-dim">
                                                            <div class="card-header border-bottom">Escape Script</div>
                                                            <div class="card-inner">
                                                                <h5 class="card-title">Escape Script</h5>
                                                                <p class="card-text">Escape Script</p>
                                                                <a href="<?= $general_url['general_value']; ?>/API/html-escape.php" class="btn btn-outline-success">See API</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                    
                                        </div>

                                </div>
                                
                        </div>
                    </div>
                </div>
                <!-- API -->
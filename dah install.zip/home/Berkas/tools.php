                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                
                                <div class="nk-block">
                                    <div class="row g-gs">
                                        
                                        
                                        

<?php
$JudulTools = htmlspecialchars(urlencode($_GET['tools']));
if(preg_match("/'|union|Order|ORDER|%0A|%0D|%22|%28|%3C|%3E|%27/",$JudulTools)){
    include'../sec.php';
} else {
                $resultJudul = mysqli_query($config, "SELECT * FROM tools2 WHERE link='$JudulTools'");
                $insertView = mysqli_query($config, "UPDATE PageView SET view = view+1 WHERE link='$JudulTools'");
                }
                while ($rowReportJudul = mysqli_fetch_array($resultJudul)) {
error_reporting(0);
?>                                
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header bg-<? echo $general_sidebar_color['general_value'] ?>"><p>
                                                <?php echo $rowReportJudul['judul']; ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
                                        <?php include'../Berkas/include.php' ?>
</div><!-- .row -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div><? } ?>
                
                
                                    </div>
                        </div>
                        <br>
                      
                      
                      <!-- Comments Item -->  
                        <div class="container">
  <div class="card">
    <div class="card-header bg-indigo"><p class="text-success">Random Comments About This Tool</p></div>
    <div class="card-body">

<?php
$ToOls = urlencode($_GET['tools']);
                $resultComments = mysqli_query($config, "SELECT * FROM comments WHERE tools='$ToOls' AND status='on' ORDER BY rand() LIMIT 5");
                if(mysqli_num_rows($resultComments) > 0) {
                while ($rowComments = mysqli_fetch_array($resultComments)) {
?>   
                                        <div class="chat is-you">
                                            <div class="chat-avatar">
                                                <div class="user-avatar bg-indigo text-success">
                                                    <?php
                                                    $userc = $rowComments['user'];
                                                    $userco = substr($userc,0,1);
                                                    $usercot = substr($userc,-1);
                                                    ?>
                                                    <span><? echo $userco.$usercot ?></span>
                                                </div>
                                            </div>
                                            <div class="chat-content">
                                                <div class="chat-bubbles">
                                                    <div class="chat-bubble">
                                                        <div class="chat-msg bg-<?= $general_sidebar_color['general_value'] ?> text-success"><?= $rowComments['comment'];?></div>
                                                    </div> 
                                                </div>
                                                <ul class="chat-meta">
                                                    <li><?= $userc ?></li>
                                                    <li><?= $rowComments['date'];?></li>
                                                </ul>
                                            </div>
                                        </div>
                                    <? }} else { echo '<center><p class="text-danger">No Comments Yet.</p></center>'; }  ?>
                                    
                                    
                                </div>
                            </div>
                </div>
                        <br>
                        <div class="container">
  <div class="card">
    <div class="card-header bg-indigo"><p class="text-success">Add Comments About This Tool</p></div>


                                        <div class="nk-reply-form">
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="reply-form">
                                                    <div class="nk-reply-form-editor">
                                                        <?php 
if(isset($_POST['comment'])) {
    $user = htmlspecialchars($_POST['user']);
    $comment = htmlspecialchars($_POST['text']);
    $tools = $_GET['tools'];
    $date = $_POST['date'];
    mysqli_query($config,"INSERT INTO `comments` (`id`, `user`, `comment`, `tools`, `date`, `status`) VALUES (NULL, '$user', '$comment', '$tools', '$date', 'on')");
    echo '<p class="alert alert-success">Success!</p>';
    echo '<script>setTimeout(function(){ window.location.replace(window.location.href); }, 1000);</script>';
}
?>
                                                        <form method="POST">
                                                        <div class="nk-reply-form-field">
                                                            <input type="text" class="form-control form-control-simple no-resize" name="user" placeholder="Your Name">
                                                            <input type="hidden" name="date" value="<?php date_default_timezone_set('Asia/Makassar'); echo date('l, d F Y h:i A');?>">
                                                        </div>
                                                        <div class="nk-reply-form-field">
                                                            <textarea class="form-control form-control-simple no-resize" name="text" placeholder="Your Comments"></textarea>
                                                        </div>
                                                        <div class="nk-reply-form-tools">
                                                            <ul class="nk-reply-form-actions g-1">
                                                                <li class="mr-2"><button class="btn btn-primary" type="submit" name="comment">Submit</button></li>
                                                            </ul>
                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            </div>
                </div>
                <!-- End Comments Item -->
                
                <!-- Menampilkan Tools yang Di Sarankan -->
                        <br>
                        <center>
                        <div class="container">
  <div class="card">
    <div class="card-header bg-indigo"><p class="text-success">Another Tools</p></div>
    <div class="card-body">
        <?php
                $resultAnother = mysqli_query($config, "SELECT * FROM tools2 ORDER BY rand() LIMIT 5");
                while ($rowReportAnother = mysqli_fetch_array($resultAnother)) {
error_reporting(0);
?>           
<a href="./?tools=<?= $rowReportAnother['link']; ?>"><button type="button"  class="btn btn-round btn-dim btn-outline-success"><?php echo $rowReportAnother['judul']; ?></button></a>&nbsp;
<? } ?>
                                </div>
                            </div>
                </div>
                </center>
                <!-- End -->
                        
                        
                    </div>
                </div>
                <!-- content @e -->    
                                        
                                        
                                    </div><!-- .row -->
                                </div><!-- .nk-block -->
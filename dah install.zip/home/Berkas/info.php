<?php
// Mendapatkan IP pengunjung menggunakan getenv()
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'IP tidak dikenali';
    return $ipaddress;
}
  
  
// Mendapatkan IP pengunjung menggunakan $_SERVER
function get_client_ip_2() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'IP tidak dikenali';
    return $ipaddress;
}
  
  
// Mendapatkan jenis web browser pengunjung
function get_client_browser() {
    $browser = '';
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'Netscape'))
        $browser = 'Netscape';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox'))
        $browser = 'Firefox';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome'))
        $browser = 'Chrome';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera'))
        $browser = 'Opera';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE'))
        $browser = 'Internet Explorer';
    else
        $browser = 'Other';
    return $browser;
} 
function up_down() {
    $up_down = '';
    $updown = round(($finish - $mulai) * 1000, 2);
    if ($updown > 1000) 
    $up_down = 'Very Slow'; 
     elseif ($updown > 100)  
    $up_down = 'Slow'; 
     else
    $up_down = 'Fast'; 
    return $up_down;
}
$UniqueVisitor = mysqli_query($config,"SELECT id, browser_device, SUM(view) AS total FROM `browser` GROUP BY id, browser_device");
$totalUniqueVisitor = 0;
while($rowtotalUniqueVisitor = mysqli_fetch_array($UniqueVisitor)){
    $totalUniqueVisitor += $rowtotalUniqueVisitor['total'];
}
$PageViewer = mysqli_query($config,"SELECT id, link, SUM(view) AS total FROM `PageView` GROUP BY id, link");
$totalPageView = 0;
while($rowtotalPageView = mysqli_fetch_array($PageViewer)){
    $totalPageView += $rowtotalPageView['total'];
}
?>                                            <div class="nk-block-head-xs">
                                                <div class="nk-block-between g-2">
                                                    <div class="nk-block-head-content">
                                                        <h6 class="nk-block-title title text-success">General Information</h6>
                                                    </div>
                                                    <div class="nk-block-head-content">
                                                        <a href="#" class="link link-primary toggle-opt active" data-target="user-info">
                                                            <div class="inactive-text">Show</div>
                                                            <div class="active-text">Hide</div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
<div class="toggle-expand-content expanded" data-content="user-info">
    <div class="card" data-content="User-Info">
        <div class="card-inner">
            <ul class="nav nav-tabs">    

                                                
                        <li class="nav-item">       
                            <a class="nav-link active" data-toggle="tab" href="#tabItem5">
                                <em class="icon ni ni-info-fill"></em>
                                <span>About</span>
                            </a>    
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#tabItem6">
                                <em class="icon ni ni-user"></em>
                                <span>Your Information</span>
                            </a>    
                        </li>  
                                                <li class="nav-item">        
                            <a class="nav-link" data-toggle="tab" href="#tabItem7">
                                <em class="icon ni ni-user-check"></em>
                                <span>Visitor</span>
                            </a>    
                        </li>
                        <li class="nav-item">        
                            <a class="nav-link" data-toggle="tab" href="#tabItem8">
                                <em class="icon ni ni-share-alt"></em>
                                <span>Privacy Policy</span>
                            </a>    
                        </li>
                        <li class="nav-item">        
                            <a class="nav-link" data-toggle="tab" href="#tabItem9">
                                <em class="icon ni ni-share-alt"></em>
                                <span>Terms & Conditions</span>
                            </a>    
                        </li>
            </ul>
            <div class="tab-content">                  
                                        
                    <div class="tab-pane active" id="tabItem5">        
                                <p><? echo $general_about['general_value'] ?>
</p>
<i>- Copyright © <?php echo date(Y) ?> Giik4You</i>
                    </div>    
                    
                                        <div class="tab-pane" id="tabItem6">        
                                                          <p>
                              <strong> This is Your Information</strong><br><?php
      echo "<b>IP : ". get_client_ip_2() ."<br>";
   echo "Browser : ".get_client_browser()."<br>";
   echo "Operation System : ".$_SERVER['HTTP_USER_AGENT']."<br>";
   echo "Load Time : " .$finish = microtime(true); print''. round(($finish - $mulai) * 2) ."<small>-ms</small> ".up_down()."<br>";
   echo "Domain : ".$_SERVER['SERVER_NAME']."<br>";
   echo "Path  : ".$_SERVER['REQUEST_URI']."<br>";
   echo "</b><br>";
?>
                          </p>   
                    </div>
                                        <div class="tab-pane" id="tabItem7">        
                                <p><?php echo "Pageviews (Week) : ".file_get_contents($filename)." <br>";
                                echo "Unique Visitor Total : $Persentase <br>";
                                echo "Tools View Total : $totalPageView "; ?></p>
                    </div>  
                    
                                        
                    <div class="tab-pane" id="tabItem8">        
                                <p>
                                    <? echo $general_terms['general_value'] ?>
</p>    
                    </div>
                                        <div class="tab-pane" id="tabItem9">        
                                <p>
                                    <? echo $general_terms['general_value'] ?>
</p>    
                    </div>                    
            </div

                                        
        </div>
    </div>
</div>
  </div> <br>
                                        <div class="row g-gs">
                                        <div class="col-md-6 col-xxl-3" data-content="views">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner mb-n2">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Top Tools View by Users</h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="nk-tb-list is-compact">
                                                    <div class="nk-tb-item nk-tb-head">
                                                        <div class="nk-tb-col"><span>Page</span></div>
                                                        <div class="nk-tb-col text-right"><span>Views</span></div>
                                                    </div><!-- .nk-tb-head -->
                                                    <?php $ResultView = mysqli_query($config,"SELECT * FROM PageView ORDER BY view DESC LIMIT 10");
                                                    while ($rowResultView = mysqli_fetch_array($ResultView)) {
                                                    ?>
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <span class="tb-sub"><a href="./?tools=<?= $rowResultView['link'] ?>"><span>/?tools=<?= $rowResultView['link'] ?></span></a></span>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $rowResultView['view']?></span></span>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <? } ?>
                                                </div><!-- .nk-tb-list -->
                                            </div><!-- .card -->
                                        </div>
                                        <div class="col-md-6 col-xxl-3">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner h-100 stretch flex-column">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Sessions by Device</h6>
                                                        </div>
                                                    </div>
                                                    <div class="device-status my-auto">
                                                        <div class="device-status-ck">
                                                            <canvas class="analytics-doughnut" id="deviceStatusData"></canvas>
                                                        </div>
                                                        <div class="device-status-group">
                                                            <div class="device-status-data">
                                                                <em data-color="#798bff" class="icon ni ni-monitor"></em>
                                                                <div class="title">Desktop</div>
                                                                <div class="amount"><?= $PersentaseDesk ?>%</div>
                                                                <div class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em><?= $DesktopDevice['view'] ?></div>
                                                            </div>
                                                            <div class="device-status-data">
                                                                <em data-color="#baaeff" class="icon ni ni-mobile"></em>
                                                                <div class="title">Mobile</div>
                                                                <div class="amount"><?= $PersentaseMob ?>%</div>
                                                                <div class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em><?= $MobileDevice['view'] ?></div>
                                                            </div>
                                                        </div><!-- .device-status-group -->
                                                    </div><!-- .device-status -->
                                                </div>
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        
                                        <div class="col-xxl-6">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner mb-n2">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Browser Used By Visitor</h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="nk-tb-list is-loose">
                                                    <div class="nk-tb-item nk-tb-head">
                                                        <div class="nk-tb-col"><span>Browser</span></div>
                                                        <div class="nk-tb-col text-right"><span>Visitor</span></div>
                                                        <div class="nk-tb-col"><span>% Visitor</span></div>
                                                    </div><!-- .nk-tb-head -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-teal icon ni ni-b-chrome"></em>
                                                                <span class="tb-lead">Google Chrome</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $chrome['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenchrome ?>"></div>
                                                                <div class="progress-amount"><?= $Persenchrome ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-blue icon ni ni-b-firefox"></em>
                                                                <span class="tb-lead">Mozilla Firefox</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $mozilla['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenmozilla ?>"></div>
                                                                <div class="progress-amount"><?= $Persenmozilla ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-info icon ni ni-b-safari"></em>
                                                                <span class="tb-lead">Safari Browser</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $safari['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persensafari ?>"></div>
                                                                <div class="progress-amount"><?= $Persensafari ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-danger icon ni ni-b-opera"></em>
                                                                <span class="tb-lead">Opera</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $opera['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenopera ?>"></div>
                                                                <div class="progress-amount"><?= $Persenopera ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-purple icon ni ni-b-si"></em>
                                                                <span class="tb-lead">Other Browser</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-right">
                                                            <span class="tb-sub tb-amount"><span><?= $otherb['view'] ?></span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="<?= $Persenotherb ?>"></div>
                                                                <div class="progress-amount"><?= $Persenotherb ?>%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                </div><!-- .nk-tb-list -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        
                                        <?php if($_SERVER["SERVER_NAME"] == 'tools.helixs.tech'){?>
                                        <div class="col-md-6 col-xxl-3">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner h-100 stretch flex-column">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Live Chat</h6>
                                                        </div>
                                                    </div><br>
                                                    <iframe src="https://www6.cbox.ws/box/?boxid=858162&boxtag=0RY2Qq" width="100%" height="500"></iframe>
                                                </div>
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        <div class="col-md-6 col-xxl-3">
                                            <div class="card card-bordered h-100">
                                                <div class="card-inner h-100 stretch flex-column">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Supported Team</h6>
                                                        </div>
                                                    </div><br>
                                                <div class="example-carousel">
                                                    <div id="carouselExCap" class="carousel slide" data-ride="carousel">
                                                        <ol class="carousel-indicators">
                                                            <li data-target="#carouselExCap" data-slide-to="0" class="active"></li>
                                                            <li data-target="#carouselExCap" data-slide-to="1"></li>
                                                            <li data-target="#carouselExCap" data-slide-to="2"></li>
                                                        </ol>
                                                        <div class="carousel-inner text-white">
                                                            <div class="carousel-item active">
                                                                <img src="https://i.ibb.co/x3fWvDP/Helix.gif" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">Helix Crew</h5>
                                                                    <p class="text-success">Learn, Teach, Work Together.</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/DfYDFgX/GLITCHO-GIF-20200112-180927.gif" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">Helix</h5>
                                                                    <p class="text-success">Helix</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/8rXd3Rf/image-png.png" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">4D Security</h5>
                                                                    <p class="text-success">Ahmad Nad</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/fqLdbTG/MCX.jpg" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">日本語-チーム| MCX</h5>
                                                                    <p class="text-success">Makassar Code XPloit Team</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/rsWLsZZ/Cyto-Xploit-TEAM-20210207-094646.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">Red Tem {CX[2662]}</h5>
                                                                    <p class="text-success">Red Team CytoXPloit | CX New Era!</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/R4jhw9W/Cyto-Xploit-TEAM-20210331-225958.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">CytoXploit</h5>
                                                                    <p class="text-success">CX New Era!</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/M7v520n/Sacred-Devil-Team-20210331-225922.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">SDT</h5>
                                                                    <p class="text-success">SDT</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/3Yk27gC/D3-C-OFFICIAL-20210331-225948.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">D3C</h5>
                                                                    <p class="text-success">D4RK 3XPLOIT CYB3R</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/VSMM14x/RST.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">RajawaliSecTeam</h5>
                                                                    <p class="text-success">Slow Down. Calm Down. Don't Worry. Don't Hurry. Trust the Process</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/VD7GQd0/TX-OFFICIAL.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">TangerangXploit Team</h5>
                                                                    <p class="text-success">Silent is Golden</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/gghG1Cx/Syborg-Cate.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">Syborg Syndicate</h5>
                                                                    <p class="text-success">Virtual World Art</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/6yPKQXp/Reborn-PBH.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">Padang Blackhat</h5>
                                                                    <p class="text-success">INDONESIAN HACKTIVIST</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/52TQTVL/SOP-ALMOST-DIE.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">System of Pekalongan</h5>
                                                                    <p class="text-success">ALMOST DIE</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/JdWPc3Y/Klaten-Ghost-S-I-LE-N-T-20210331-225913.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">Klaten Ghost | Reborn</h5>
                                                                    <p class="text-success">HACKTIVIST NDESO</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <img src="https://i.ibb.co/y8ZFXMr/ATOMSEC7.jpg" alt="image" class="d-block w-100" >
                                                                <div class="carousel-caption d-none d-md-block">
                                                                    <h5 class="text-success">ATOMSEC7</h5>
                                                                    <p class="text-success">ATOMSEC7</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <a class="carousel-control-prev" href="#carouselExCap" role="button" data-slide="prev">
                                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                            <span class="sr-only">Previous</span>
                                                        </a>
                                                        <a class="carousel-control-next" href="#carouselExCap" role="button" data-slide="next">
                                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                            <span class="sr-only">Next</span>
                                                        </a>
                                                    </div>
                                                </div>
                                           </div>
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        <? } ?>
                                    </div>
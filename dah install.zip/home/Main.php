<?php
include'../general.php';
include'helixdata/head.php';
include'helixdata/sidebar.php';
include'helixdata/bread.php';?>
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <? echo $ads1['general_value'] ?><br>
                                <? echo $ads1['general_value'] ?><br>
                                <?php include'./Berkas/info.php';?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
                
<?php include'./helixdata/footer.php' ?>